using System;
using UnityEngine;
using UnityEngine.UI;

public class MachineTool : MonoBehaviour
{
    [SerializeField] private Image _window;
    [SerializeField] private Tank _tank;

    public static Action upgraded;

    public void OpenUpgradeWindow()
    {
        _window.gameObject.SetActive(true);
    }

    public void Upgrade()
    {
        upgraded?.Invoke();
    }
}