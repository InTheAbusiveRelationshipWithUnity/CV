using UnityEngine;

public class Motion : MonoBehaviour
{
    public static Motion instance;

    private float targetSpeed = 0f;
    private float currentSpeed = 0f;

    public float movement = 0f;
    [SerializeField] private AnimationCurve acceleration; // �������� ��������� �������

    [SerializeField] private float _maxSpeed; // ������������ �������� �������
    [SerializeField] private float _maxTorque = 10000f; // ������������ �������� ������

    [SerializeField] private WheelJoint2D[] wheels;

    private JointMotor2D _motor;
    private Rigidbody rb;

    public GroundSpawner[] groundSpawners;

    private void Awake()
    {
        instance = this;

        SetAccelerationKeys();
    }

    private void Update()
    {
        Move();
    }

    private void FixedUpdate()
    {
        if (movement != 0f)
        {
            targetSpeed = Mathf.Clamp(targetSpeed + movement * Time.deltaTime, -_maxSpeed, _maxSpeed);
        }
        else
        {
            targetSpeed = 0f;
        }

        currentSpeed = Mathf.MoveTowards(currentSpeed, targetSpeed, acceleration.Evaluate(targetSpeed) * 8f);
        ApplySpeedToWheels(currentSpeed);
    }
    
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.transform.name == "Collider")
            groundSpawners[0].TriggerTouch();
        else if (collision.transform.name == "Collider1")
            groundSpawners[1].TriggerTouch();
    }

    private void Move()
    {
        movement = -500;
    }

    private void ApplySpeedToWheels(float speed)
    {
        for (int i = 0; i < wheels.Length; i++)
        {
            _motor.motorSpeed = speed;
            _motor.maxMotorTorque = _maxTorque;
            wheels[i].useMotor = true;
            wheels[i].motor = _motor;
        }
    }

    private void SetAccelerationKeys()
    {
        acceleration = new AnimationCurve();
        acceleration.AddKey(new Keyframe(-_maxSpeed, 0.2f));
        acceleration.AddKey(new Keyframe(0, 0.8f));
        acceleration.AddKey(new Keyframe(_maxSpeed, 0.2f));
    }
}