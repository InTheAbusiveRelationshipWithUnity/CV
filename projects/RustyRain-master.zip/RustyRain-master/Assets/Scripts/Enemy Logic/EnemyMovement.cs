using UnityEngine;

public class EnemyMovement : MonoBehaviour
{
    private float targetSpeed = 0f;
    private float currentSpeed = 0f;

    [SerializeField] private float _range = 40f;

    [SerializeField] private Armor _armor;
    [SerializeField] private Tank _tank;

    public float movement = 0f;
    [SerializeField] private AnimationCurve acceleration; 

    [SerializeField] private float _maxTorque = 10000f;

    [SerializeField] private WheelJoint2D[] wheels;

    [SerializeField] private ParticleSystem[] _groundEffects;

    private JointMotor2D _motor;
    private Rigidbody rb;

    private void Awake()
    {
        SetAccelerationKeys();
    }

    private void Update()
    {
        if (!_armor.caterpillar.IsBroken)
            Move();
    }

    private void FixedUpdate()
    {
        if (movement != 0f)
        {
            targetSpeed = Mathf.Clamp(targetSpeed + movement * Time.deltaTime, -_tank.MaxSpeed, _tank.MaxSpeed);
            OnEffects();
        }
        else
        {
            targetSpeed = 0f;
        }

        currentSpeed = Mathf.MoveTowards(currentSpeed, targetSpeed, acceleration.Evaluate(targetSpeed) * 8f);
        ApplySpeedToWheels(currentSpeed);
    }

    private void Move()
    {
        Collider2D[] players = Physics2D.OverlapCircleAll(gameObject.transform.position, _range, LayerMask.GetMask("Player"));
        if (players.Length > 0)
        {
            if (Mathf.Abs(transform.position.x) - Mathf.Abs(players[0].transform.position.x) < 15f && Mathf.Abs(transform.position.y - players[0].transform.position.y) < 2f)
            {
                movement = 0f;
                OffEffects();
            }
            else
                movement = 10 * _tank.MaxSpeed * players[0].transform.position.x / Mathf.Abs(players[0].transform.position.x);
        }
        else
        {
            movement = 0f;
        }
    }

    private void ApplySpeedToWheels(float speed)
    {
        for (int i = 0; i < wheels.Length; i++)
        {
            _motor.motorSpeed = speed;
            _motor.maxMotorTorque = _maxTorque;
            wheels[i].useMotor = true;
            wheels[i].motor = _motor;
        }
    }

    private void SetAccelerationKeys()
    {
        acceleration = new AnimationCurve();
        acceleration.AddKey(new Keyframe(-_tank.MaxSpeed, 0.2f));
        acceleration.AddKey(new Keyframe(0, 0.8f));
        acceleration.AddKey(new Keyframe(_tank.MaxSpeed, 0.2f));
    }

    private void OffEffects()
    {
        foreach (var i in _groundEffects)
        {
            i.gameObject.SetActive(false);
        }
    }

    private void OnEffects()
    {
        foreach (var i in _groundEffects)
        {
            i.gameObject.SetActive(true);
        }
    }
}
