using UnityEngine;

public class Bullet : MonoBehaviour
{
    [SerializeField] private float _bulletSpeed = 50f;

    [SerializeField] private Rigidbody2D _rb;

    public void StartMovement(Transform firePoint)
    {
        _rb.AddForce(firePoint.right * _bulletSpeed, ForceMode2D.Impulse);
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        Destroy(gameObject);
    }
}
