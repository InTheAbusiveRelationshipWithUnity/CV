using System.Collections;
using UnityEngine;

public class MachineToolActivate : MonoBehaviour
{
    [SerializeField] private Transform _stanok;

    private Camera _camera;
    private Transform _player;
    private CameraFollow _cameraFollow;

    private void Start()
    {
        _camera = Camera.main;
        _player = GameObject.FindGameObjectWithTag("Player").transform;
        _cameraFollow = GetComponent<CameraFollow>();
    }

    public void GoToStanok()
    {
        StartCoroutine(GoToStanok(_stanok.transform));
        _cameraFollow.isActive = false;
    }

    public IEnumerator GoToStanok(Transform pos)
    {
        while (Vector3.Distance(_camera.transform.position, pos.position) > 2)
        {
            _camera.transform.position = Vector3.Lerp(_camera.transform.position, pos.position, 1.3f * Time.deltaTime);
            yield return null;
        }
    }

    public IEnumerator GoToTank()
    {
        while (Vector3.Distance(_camera.transform.position, _player.position) > 2)
        {
            _camera.transform.position = Vector3.Lerp(_camera.transform.position, _player.position, Time.deltaTime);
            yield return null;
        }
        _cameraFollow.isActive = true;
    }
}
