using System;
using UnityEngine;

public class Armor : MonoBehaviour
{
    [SerializeField] private Fire _fireSystemForPlayer;
    [SerializeField] private EnemyShootingSystem _enemyShootingSystem;

    [SerializeField] private GameObject _caterpillar;
    [SerializeField] private GameObject _brokenCaterpillar;

    public float armorThickness = 120f;

    public Weapon weapon;
    public Caterpillar caterpillar;

    private void Awake()
    {
        weapon = new Weapon();
        caterpillar = new Caterpillar
        {
            caterpillarInClass = _caterpillar,
            brokenCaterpillarInClass = _brokenCaterpillar
        };
    }

    public void FixModules()
    {
        weapon.Fix();
        caterpillar.Fix();
    }

    public class Weapon : Armor
    {
        private bool _isBroken = false;

        public bool IsBroken { get { return _isBroken; } }

        [System.Obsolete]
        public void TakeDamage(float damage)
        {
            int brokeIndex = Convert.ToInt32(armorThickness / damage);
            float chanceToBroke = UnityEngine.Random.RandomRange(1, 2 * brokeIndex);

            if (chanceToBroke == 1)
            {
                _isBroken = true;
                if (_fireSystemForPlayer != null)
                    _fireSystemForPlayer.canFire = false;
                else
                    _enemyShootingSystem.canFire = false;
            }
        }

        public void Fix()
        {
            _isBroken = false;
            if (_fireSystemForPlayer != null)
                _fireSystemForPlayer.canFire = true;
            else
                _enemyShootingSystem.canFire = true;
        }
    }

    public class Caterpillar : Armor
    {
        private bool _isBroken;

        public GameObject caterpillarInClass;
        public GameObject brokenCaterpillarInClass;

        public bool IsBroken { get { return _isBroken; } }

        [System.Obsolete]
        public void TakeDamage(float damage)
        {
            int chanceBust = 0;
            if (armorThickness / damage < 1.5 && armorThickness / damage > 1)
                chanceBust = 3;
            else if (armorThickness / damage >= 1.5)
                chanceBust = 2;
            else
                chanceBust = 4;

            float chanceToBroke = UnityEngine.Random.RandomRange(1, chanceBust);

            if (chanceToBroke >= 1 && chanceToBroke <= 2)
            {
                _isBroken = true;
                caterpillarInClass.SetActive(false);
                brokenCaterpillarInClass.SetActive(true);
            }
        }

        public void Fix()
        {
            _isBroken = false;
            caterpillarInClass.SetActive(true);
            brokenCaterpillarInClass.SetActive(false);
        }
    }

    public void ArmorSmaller(float _damage)
    {
        armorThickness -= _damage / 10;
    }
}
