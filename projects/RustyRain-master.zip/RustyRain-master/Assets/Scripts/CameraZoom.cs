using UnityEngine;

public class CameraZoom : MonoBehaviour
{
    [SerializeField] private Camera _camera;

    [SerializeField] private bool _inHangar;

    private float _scalingModFactor = 1f; //� ����������� �� ����, ����������� �� �� orthographicSize ������ ��� ���������, ���������� ��������� �������� +/- 1
    private float _cameraMoveFactor = 1f;

    [SerializeField] private float _currentMaxZoomCoefficient = 1.91f;
    [SerializeField] private float _currentMinCoefficient = 0.6f;

    private float _zoomCoefficient;

    private bool _clickIsDetected = false;
    private float _pressingTime;

    private void Start()
    {
        _zoomCoefficient = _camera.orthographicSize;
    }

    private void Update()
    {
        if (_clickIsDetected)
        {
            if (_inHangar)
                _zoomCoefficient -= 0.006f * _scalingModFactor;
            else
                _zoomCoefficient -= 0.01f * _scalingModFactor;
            _camera.orthographicSize = _zoomCoefficient;
            _camera.transform.position = new Vector3(_camera.transform.position.x, _camera.transform.position.y - 0.0006f * _scalingModFactor * _cameraMoveFactor, _camera.transform.position.z);
        }

        if (_zoomCoefficient < _currentMinCoefficient)
        {
            _zoomCoefficient = _currentMinCoefficient;
            _clickIsDetected = false;
        }

        else if (_zoomCoefficient > _currentMaxZoomCoefficient)
        {
            _zoomCoefficient = _currentMaxZoomCoefficient;
            _clickIsDetected = false;
        }
    }

    public void ClickDetected()
    {
        _pressingTime = Time.time;
        _clickIsDetected = true;
    }

    public void ClickDeselect()
    {
        _clickIsDetected = false;
        if (Time.time - _pressingTime < 0.1f)
            _scalingModFactor = -_scalingModFactor;
    }
}
