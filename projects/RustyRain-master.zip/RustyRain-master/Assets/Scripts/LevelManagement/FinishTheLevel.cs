using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class FinishTheLevel : MonoBehaviour
{
    [SerializeField] private Image _endImage;

    private void OnTriggerEnter2D(Collider2D collider)
    {
        if (collider != null)
            if (collider.CompareTag("PlayerTank"))
            {
                EndTheLevel();
            }
    }

    private void EndTheLevel()
    {
        _endImage.gameObject.SetActive(true);

        MovementController.instance.canDrive = false;
    }

    public void Continue()
    {
        SceneManager.LoadScene(1);
    }
}