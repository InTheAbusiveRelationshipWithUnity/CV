using UnityEngine;

public class OtherIndicators : MonoBehaviour
{
    [SerializeField] private Dashboard _dashboard;

    private float _startEngineTemp = 0f;
    public float _currentEngineTemp;
    private float _timeToFreeze;
    private float _heatingArg = 1f;

    private readonly float _startOilValue = 1500f;
    private float _currentOilValue;

    private bool _engineIsStarted = false;

    private void Start()
    {
        _currentEngineTemp = _startEngineTemp;
        _currentOilValue = _startOilValue;

        _timeToFreeze = Time.time;
    }

    private void Update()
    {
        if (Time.time - _timeToFreeze > 25f && _engineIsStarted)
            FreezeTheEngine();
        else
            HeatingTheEngine();

        if (_currentOilValue < 130f)
            _heatingArg = 1.7f;
    }

    private void FixedUpdate()
    {
        if (_dashboard.isActiveAndEnabled)
        {
            _dashboard.temp.UpdateTemp(_currentEngineTemp);
            _dashboard.oil.UpdateValue(_currentOilValue);
        }
    }

    private void OnEnable()
    {
        EngineStart.engineIsStarted += StartEngine;
    }

    private void OnDisable()
    {
        EngineStart.engineIsStarted -= StartEngine;
    }

    private void StartEngine()
    {
        _engineIsStarted = true;
    }

    private void HeatingTheEngine()
    {
        if (_engineIsStarted)
        {
            _currentEngineTemp += 0.003f * _heatingArg;
            _timeToFreeze = Time.time;

            _currentOilValue -= 0.008f;
        }
    }

    private void FreezeTheEngine()
    {
        if (_engineIsStarted)
        {
            _currentEngineTemp -= 0.004f;
        }
    }
}