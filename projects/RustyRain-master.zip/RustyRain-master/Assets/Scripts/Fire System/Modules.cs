using System;
using UnityEngine;

public class Modules : MonoBehaviour
{
    [SerializeField] private Sprite _engineIcon;
    [SerializeField] private Sprite _ammunitionIcon;
    [SerializeField] private Sprite _fuelIcon;
    [SerializeField] private Sprite _crewIcon;

    public static Action engineWasBroken;
    public static Action ammunitionWasBroken;
    public static Action crewGottenHit;

    public Engine engine;
    public Ammunition ammunition;
    public FuelTank fuelTank;
    public Commander commander;
    public MechanicDriver mechanicDriver;
    public TankLoader tankLoader;

    public DamageSystem damageSystem;
    public ModulesBar bar;

    public bool _isEnemy = false;

    private void Awake()
    {
        if (_isEnemy)
        {
            engine = new Engine
            {
                isEnemy = true,
                damageSystem = this.damageSystem,
                bar = this.bar,
                engineIcon = this._engineIcon
            };
            ammunition = new Ammunition
            {
                isEnemy = true,
                damageSystem = this.damageSystem,
                bar = this.bar,
                ammunitionIcon = this._ammunitionIcon
            };
            fuelTank = new FuelTank
            {
                isEnemy = true,
                damageSystem = this.damageSystem,
                bar = this.bar,
                fuelIcon = this._fuelIcon
            };
            commander = new Commander
            {
                isEnemy = true,
                damageSystem = this.damageSystem,
                bar = this.bar,
                crewIcon = this._crewIcon
            };
            tankLoader = new TankLoader
            {
                isEnemy = true,
                damageSystem = this.damageSystem,
                bar = this.bar,
                crewIcon= this._crewIcon
            };
            mechanicDriver = new MechanicDriver
            {
                isEnemy = true,
                damageSystem = this.damageSystem,
                bar = this.bar, 
                crewIcon = this._crewIcon
            };
        }
        else
        {
            engine = new Engine { bar = this.bar };
            ammunition = new Ammunition { bar = this.bar };
            fuelTank = new FuelTank { bar = this.bar };
            commander = new Commander { bar = this.bar };
            tankLoader = new TankLoader { bar = this.bar };
            mechanicDriver = new MechanicDriver { bar = this.bar };
        }
    }

    public void FixAllModules()
    {
        engine.Fix();
        ammunition.Fix();
        fuelTank.Fix();

        bar.TurnOffModulesIcons();
    }

    public void HealAllCrews()
    {
        commander.Fix();
        tankLoader.Fix();
        mechanicDriver.Fix();


        bar.TurnOffCrewIcons();
    }   

    public void ApplyDamge(float damage, string name)
    {
        switch (name)
        {
            case "Engine":
                engine.TakeDamage(damage);
                break;
            case "Ammunition":
                ammunition.TakeDamage(damage);
                break;
            case "Commander":
                commander.TakeDamage(damage);
                break;
            case "MechanicDriver":
                mechanicDriver.TakeDamage(damage);
                break;
            case "FuelTank":
                fuelTank.TakeDamage(damage);
                break;
            case "TankLoader":
                tankLoader.TakeDamage(damage);
                break;
        }
    }

    public class Engine
    {
        public bool isEnemy = false;
        public DamageSystem damageSystem;
        public ModulesBar bar;
        public Sprite engineIcon;

        private float _healthPoints = 100;
        private int _numberOfModule = 0;
        private bool _isBroken = false;

        public bool IsBroken { get { return _isBroken; } }

        public void TakeDamage(float damage)
        {
            _healthPoints -= damage;

            if (_healthPoints <= 50 && _healthPoints > 0)
                if (isEnemy)
                    damageSystem.OnCriticalHitEnter(engineIcon, _numberOfModule);
                else
                    bar.OnHitEnter(_numberOfModule);


            else if (_healthPoints <= 0 && _isBroken == false)
            {
                _healthPoints = 0;
                _isBroken = true;

                if (isEnemy)
                {
                    damageSystem.OnCriticalHitEnter(engineIcon, _numberOfModule);
                }
                else
                {
                    bar.OnCriticalHitEnter(_numberOfModule);
                    engineWasBroken?.Invoke();
                }
            }
        }

        public void Fix()
        {
            _isBroken = false;
        }
    }

    public class Ammunition
    {
        public bool isEnemy = false;
        public DamageSystem damageSystem;
        public ModulesBar bar;
        public Sprite ammunitionIcon;

        private float _healthPoints = 100;
        private int _numberOfModule = 1;
        private bool _isBroken = false;

        public bool IsBroken { get { return _isBroken; } }

        public void TakeDamage(float damage)
        {
            _healthPoints -= damage;

            if (_healthPoints <= 50 && _healthPoints > 0)
                if (isEnemy)
                    damageSystem.OnCriticalHitEnter(ammunitionIcon, _numberOfModule);
                else
                    bar.OnHitEnter(_numberOfModule);

            else if (_healthPoints <= 0 && _isBroken == false)
            {
                _healthPoints = 0;
                _isBroken = true;

                if (isEnemy)
                {
                    damageSystem.OnCriticalHitEnter(ammunitionIcon, _numberOfModule);
                }
                else
                {
                    bar.OnCriticalHitEnter(_numberOfModule);
                    Fire.instance.canFire = false;
                    ammunitionWasBroken?.Invoke();
                }
            }         
        }

        public void Fix()
        {
            _isBroken = false;
        }
    }

    public class FuelTank
    {
        public bool isEnemy = false;
        public DamageSystem damageSystem;
        public ModulesBar bar;
        public Sprite fuelIcon;

        public bool _isBroken = false;

        private float _healthPoints = 100;
        private int _numberOfModule = 2;

        public bool IsBroken { get { return _isBroken; } }

        public void TakeDamage(float damage)
        {
            _healthPoints -= damage;

            if (_healthPoints <= 50 && _healthPoints > 0)
                if (isEnemy)
                    damageSystem.OnCriticalHitEnter(fuelIcon, _numberOfModule);
                else
                    bar.OnHitEnter(_numberOfModule);

            else if (_healthPoints <= 0 && _isBroken == false)
            {
                _healthPoints = 0;
                _isBroken = true;

                if (isEnemy)
                    damageSystem.OnCriticalHitEnter(fuelIcon, _numberOfModule);
                else
                    bar.OnCriticalHitEnter(_numberOfModule);
            }
        }

        public void Fix()
        {
            _isBroken = false;
        }
    }

    public class Commander
    {
        public bool isEnemy = false;
        public DamageSystem damageSystem;
        public ModulesBar bar;
        public Sprite crewIcon;

        private float _healthPoints = 100;
        private int _numberOfModule = 3;
        private bool _isBroken = false;

        public bool IsBroken { get { return _isBroken; } }

        public void TakeDamage(float damage)
        {
            _healthPoints -= damage;

            if (_healthPoints <= 50 && _healthPoints > 0)
                if (isEnemy)
                    damageSystem.OnCriticalHitEnter(crewIcon, _numberOfModule);
                else
                    bar.OnHitEnter(_numberOfModule);

            else if (_healthPoints <= 0 && _isBroken == false)
            {
                _healthPoints = 0;
                _isBroken = true;

                if (isEnemy)
                {
                    damageSystem.OnCriticalHitEnter(crewIcon, _numberOfModule);
                }
                else
                {
                    bar.OnCriticalHitEnter(_numberOfModule);
                    crewGottenHit?.Invoke();
                }
            }
        }

        public void Fix()
        {
            _isBroken = false;
        }
    }

    public class TankLoader
    {
        public bool isEnemy = false;
        public DamageSystem damageSystem;
        public ModulesBar bar;
        public Sprite crewIcon;

        private float _healthPoints = 100;
        private int _numberOfModule = 3;
        private bool _isBroken = false;

        public bool IsBroken { get { return _isBroken; } }

        public void TakeDamage(float damage)
        {
            _healthPoints -= damage;

            if (_healthPoints <= 50 && _healthPoints > 0)
                if (isEnemy)
                    damageSystem.OnCriticalHitEnter(crewIcon, _numberOfModule);
                else
                    bar.OnHitEnter(_numberOfModule);

            else if (_healthPoints <= 0)
            {
                _healthPoints = 0;
                _isBroken = true;

                if (isEnemy)
                {
                    damageSystem.OnCriticalHitEnter(crewIcon, _numberOfModule);
                }
                else
                {
                    bar.OnCriticalHitEnter(_numberOfModule);
                    Fire.instance.canFire = false;
                    crewGottenHit?.Invoke();
                }
            }
        }

        public void Fix()
        {
            _isBroken = false;
        }
    }

    public class MechanicDriver
    {
        public bool isEnemy = false;
        public DamageSystem damageSystem;
        public ModulesBar bar;
        public Sprite crewIcon;

        private float _healthPoints = 100;
        private int _numberOfModule = 3;
        private bool _isBroken = false;

        public bool IsBroken { get { return _isBroken; } }

        public void TakeDamage(float damage)
        {
            _healthPoints -= damage;

            if (_healthPoints <= 50 && _healthPoints > 0)
                if (isEnemy)
                    damageSystem.OnCriticalHitEnter(crewIcon, _numberOfModule);
                else
                    bar.OnHitEnter(_numberOfModule);

            else if (_healthPoints <= 0 && _isBroken == false)
            {
                _healthPoints = 0;
                _isBroken = true;

                if (isEnemy)
                {
                    damageSystem.OnCriticalHitEnter(crewIcon, _numberOfModule);
                }
                else
                {
                    bar.OnCriticalHitEnter(_numberOfModule);
                    crewGottenHit?.Invoke();
                }
            }
        }

        public void Fix()
        {
            _isBroken = false;
        }
    }
}