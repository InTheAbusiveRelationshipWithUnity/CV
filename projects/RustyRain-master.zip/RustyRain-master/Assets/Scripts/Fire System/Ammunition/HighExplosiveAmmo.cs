using UnityEngine;

public class HighExplosiveAmmo : MonoBehaviour
{
    [SerializeField] private float _bulletSpeed = 10f;

    [SerializeField] private float _radiusOfFragmentsScattering = 5f;
    [SerializeField] private float _armorPenetration = 120f;
    [SerializeField] private float _damage = 50f;

    [SerializeField] private Rigidbody2D _rb;

    private void Start()
    {
        _rb.AddForce(Fire.instance._firePoint.right * _bulletSpeed, ForceMode2D.Impulse);
    }

    [System.Obsolete]
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.collider.GetComponentInParent<Armor>())
        {
            Armor armor = collision.collider.GetComponentInParent<Armor>();

            if (collision.collider.name == "Weapon")
            {
                armor.weapon.TakeDamage(_damage);
            }

            else if (collision.collider.name == "Caterpillar")
            {
                armor.caterpillar.TakeDamage(_damage);
            }

            else if (collision.collider.name == "ArmorPlate")
            {
                if (_armorPenetration >= armor.armorThickness)
                {
                    Collider2D[] modules = Physics2D.OverlapCircleAll(transform.position, 4f, LayerMask.GetMask("Module"));
                    Modules modulesParent = collision.collider.GetComponentInChildren<Modules>();

                    for (int i = 0; i < modules.Length; i++)
                    {
                        modulesParent.ApplyDamge(_damage, modules[i].gameObject.name);
                    }
                }
                else
                    armor.ArmorSmaller(_damage);
            }
        }
    }
}
