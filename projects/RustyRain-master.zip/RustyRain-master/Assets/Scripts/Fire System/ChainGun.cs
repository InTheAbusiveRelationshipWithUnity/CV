using System.Collections;
using UnityEngine;

public class ChainGun : MonoBehaviour
{
    [SerializeField] private Transform[] _chainGuns;
    [SerializeField] private Transform _firePoint;

    [SerializeField] private GameObject _bullet;
    [SerializeField] private float _firingDelay = 0.1f;

    private float _timeBetweenFire = 0f;
    private int[] _shots;

    private bool _buttonHold = false;

    private void Start()
    {
        _shots = new int[_chainGuns.Length];

        for (int i = 0;  i < _chainGuns.Length; i++)
        {
            _shots[i] = 50;
        }
    }

    private void Update()
    {
        if (Input.GetKey(KeyCode.Space) || _buttonHold)
        {
            Fire();
        }
    }

    private void Fire()
    {
        if (Time.time - _timeBetweenFire >= _firingDelay)
        {
            _timeBetweenFire = Time.time;

            for (int i = 0; i < _chainGuns.Length; i++)
            {
                if (_shots[i] > 0)
                {
                    var bullet = Instantiate(_bullet, _chainGuns[i].position, _chainGuns[i].rotation).GetComponent<Bullet>();
                    bullet.StartMovement(_firePoint);
                    _shots[i] -= 1;
                }
                else
                {
                    StartCoroutine(Reload(i));
                }
            }
        }
    }

    private IEnumerator Reload(int i)
    {
        yield return new WaitForSeconds(5f);

        _shots[i] = 50;
    }

    public void OnButtonDown()
    {
        _buttonHold = true;
    }

    public void OnButtonUp()
    {
        _buttonHold = false;
    }
}
