using System;
using UnityEngine;

public class Tank : MonoBehaviour
{
    [SerializeField] private float _reloadTime = 4;
    [SerializeField] private float _maxSpeed = 10000;
    [SerializeField] private float _aimSpeed = 0.1f;
    [SerializeField] private float _maxVisionRange = 450;

    public float ReloadTime { get { return _reloadTime; } }
    public float MaxSpeed { get { return _maxSpeed; } }
    public float AimSpeed { get { return _aimSpeed; } }
    public float MaxVisionRange { get { return _maxVisionRange; } }

    public DamageSystem damageSystem;
    public ModulesBar bar;

    private Engine _engine;
    private Ammunition _ammunition;
    private FuelTank _fuelTank;
    private Commander _commander;
    private MechanicDriver _mechanicDriver;
    private TankLoader _tankLoader;

    private void OnEnable()
    {
        MachineTool.upgraded += ApplyUpgrades;
    }

    private void OnDisable()
    {
        MachineTool.upgraded -= ApplyUpgrades;
    }

    private void Start()
    {
        if (TryGetComponent<DamageSystem>(out var system))
        {
            damageSystem = system;

            _engine = new Engine { damageSystem = this.damageSystem };
            _ammunition = new Ammunition() { damageSystem = this.damageSystem };
            _commander = new Commander() { damageSystem = this.damageSystem };
            _mechanicDriver = new MechanicDriver() { damageSystem = this.damageSystem };
            _fuelTank = new FuelTank() { damageSystem = this.damageSystem };
            _tankLoader = new TankLoader() { damageSystem = this.damageSystem };
        }
        else
        {
            var sys = GetComponent<ModulesBar>();
            bar = sys;

            _engine = new Engine { bar = this.bar };
            _ammunition = new Ammunition() { bar = this.bar };
            _commander = new Commander() { bar = this.bar };
            _mechanicDriver = new MechanicDriver() { bar = this.bar };
            _fuelTank = new FuelTank() { bar = this.bar };
            _tankLoader = new TankLoader() { bar = this.bar };
        }
    }

    private void ApplyUpgrades()
    {
        _reloadTime += 0.1f;
    }

    private void Change(int numberOfChangeGroup, float damage)
    {
        if (numberOfChangeGroup == 0)
            _maxSpeed = _maxSpeed / ((_engine.HealthPoints + damage) / 100) * (_engine.HealthPoints / 100);
        else if (numberOfChangeGroup == 1)
            _reloadTime += _reloadTime * (damage / 100);
        else if (numberOfChangeGroup == 2)
            _maxVisionRange = _maxVisionRange / ((_commander.HealthPoint + damage) / 100) * (_commander.HealthPoint / 100);
        else if (numberOfChangeGroup == 3)
            _aimSpeed = _aimSpeed / ((_commander.HealthPoint + damage) / 100) * (_commander.HealthPoint / 100);
    }

    public void ApplyDamge(float damage, string name)
    {
        switch (name)
        {
            case "Engine":
                _engine.TakeDamage(damage);
                Change(0, damage);
                break;
            case "Ammunition":
                _ammunition.TakeDamage(damage);
                Change(1, damage);
                break;
            case "Commander":
                _commander.TakeDamage(damage);
                Change(2, damage);
                Change(3, damage);
                break;
            case "MechanicDriver":
                _mechanicDriver.TakeDamage(damage);
                Change(0, damage);
                break;
            case "FuelTank":
                _fuelTank.TakeDamage(damage);
                break;
            case "TankLoader":
                _tankLoader.TakeDamage(damage);
                Change(1, damage);
                break;
        }
    }

    public class Engine
    {
        public DamageSystem damageSystem;
        public ModulesBar bar;

        private readonly int _numberOfModule = 0;
        private bool _isBroken = false;
        private float _healthPoints = 100;

        public float HealthPoints { get { return _healthPoints; } }
        public bool IsBroken { get { return _isBroken; } }

        public void TakeDamage(float damage)
        {
            _healthPoints -= damage;

            if (_healthPoints <= 50 && _healthPoints > 0)
            {
                
                if (damageSystem != null)
                    damageSystem.OnCriticalHitEnter(false, _numberOfModule);
                else
                    bar.OnHitEnter(_numberOfModule);
            }


            else if (_healthPoints <= 0 && _isBroken == false)
            {
                _healthPoints = 0;
                _isBroken = true;

                if (damageSystem != null)
                {
                    damageSystem.OnCriticalHitEnter(true, _numberOfModule);
                }
                else
                {
                    bar.OnCriticalHitEnter(_numberOfModule);
                }
            }
        }

        public void Fix()
        {
            _isBroken = false;
        }
    }

    public class Ammunition
    {
        public DamageSystem damageSystem;
        public ModulesBar bar;

        private float _healthPoints = 100;
        private readonly int _numberOfModule = 1;
        private bool _isBroken = false;

        public float HealthPoint { get { return _healthPoints; } }
        public bool IsBroken { get { return _isBroken; } }

        public void TakeDamage(float damage)
        {
            _healthPoints -= damage;
            if (_healthPoints <= 50 && _healthPoints > 0)
                if (damageSystem != null)
                    damageSystem.OnCriticalHitEnter(false, _numberOfModule);
                else
                    bar.OnHitEnter(_numberOfModule);


            else if (_healthPoints <= 0 && _isBroken == false)
            {
                _healthPoints = 0;
                _isBroken = true;

                if (damageSystem != null)
                {
                    damageSystem.OnCriticalHitEnter(true, _numberOfModule);
                }
                else
                {
                    bar.OnCriticalHitEnter(_numberOfModule);
                }
            }
        }

        public void Fix()
        {
            _isBroken = false;
        }
    }

    public class FuelTank
    {
        public DamageSystem damageSystem;
        public ModulesBar bar;

        public bool _isBroken = false;

        private float _healthPoints = 100;
        private readonly int _numberOfModule = 2;

        public bool IsBroken { get { return _isBroken; } }

        public void TakeDamage(float damage)
        {
            _healthPoints -= damage;
            if (_healthPoints <= 50 && _healthPoints > 0)
                if (damageSystem != null)
                    damageSystem.OnCriticalHitEnter(false, _numberOfModule);
                else
                    bar.OnHitEnter(_numberOfModule);


            else if (_healthPoints <= 0 && _isBroken == false)
            {
                _healthPoints = 0;
                _isBroken = true;

                if (damageSystem != null)
                {
                    damageSystem.OnCriticalHitEnter(true, _numberOfModule);
                }
                else
                {
                    bar.OnCriticalHitEnter(_numberOfModule);
                }
            }
        }

        public void Fix()
        {
            _isBroken = false;
        }
    }

    public class Commander
    {
        public DamageSystem damageSystem;
        public ModulesBar bar;

        private float _healthPoints = 100;
        private readonly int _numberOfModule = 3;
        private bool _isBroken = false;

        public float HealthPoint { get { return _healthPoints; } }
        public bool IsBroken { get { return _isBroken; } }

        public void TakeDamage(float damage)
        {
            _healthPoints -= damage;
            if (_healthPoints <= 50 && _healthPoints > 0)
                if (damageSystem != null)
                    damageSystem.OnCriticalHitEnter(false, _numberOfModule);
                else
                    bar.OnHitEnter(_numberOfModule);


            else if (_healthPoints <= 0 && _isBroken == false)
            {
                _healthPoints = 0;
                _isBroken = true;

                if (damageSystem != null)
                {
                    damageSystem.OnCriticalHitEnter(true, _numberOfModule);
                }
                else
                {
                    bar.OnCriticalHitEnter(_numberOfModule);
                }
            }
        }

        public void Fix()
        {
            _isBroken = false;
        }
    }

    public class TankLoader
    {
        public DamageSystem damageSystem;
        public ModulesBar bar;

        private float _healthPoints = 100;
        private readonly int _numberOfModule = 3;
        private bool _isBroken = false;

        public float HealthPoint { get { return _healthPoints; } }
        public bool IsBroken { get { return _isBroken; } }

        public void TakeDamage(float damage)
        {
            _healthPoints -= damage;
            if (_healthPoints <= 50 && _healthPoints > 0)
                if (damageSystem != null)
                    damageSystem.OnCriticalHitEnter(false, _numberOfModule);
                else
                    bar.OnHitEnter(_numberOfModule);


            else if (_healthPoints <= 0 && _isBroken == false)
            {
                _healthPoints = 0;
                _isBroken = true;

                if (damageSystem != null)
                {
                    damageSystem.OnCriticalHitEnter(true, _numberOfModule);
                }
                else
                {
                    bar.OnCriticalHitEnter(_numberOfModule);
                }
            }
        }

        public void Fix()
        {
            _isBroken = false;
        }
    }

    public class MechanicDriver
    {
        public DamageSystem damageSystem;
        public ModulesBar bar;

        private float _healthPoints = 100;
        private readonly int _numberOfModule = 3;
        private bool _isBroken = false;

        public float HealthPoint { get { return _healthPoints; } }
        public bool IsBroken { get { return _isBroken; } }

        public void TakeDamage(float damage)
        {
            _healthPoints -= damage;
            if (_healthPoints <= 50 && _healthPoints > 0)
                if (damageSystem != null)
                    damageSystem.OnCriticalHitEnter(false, _numberOfModule);
                else
                    bar.OnHitEnter(_numberOfModule);


            else if (_healthPoints <= 0 && _isBroken == false)
            {
                _healthPoints = 0;
                _isBroken = true;

                if (damageSystem != null)
                {
                    damageSystem.OnCriticalHitEnter(true, _numberOfModule);
                }
                else
                {
                    bar.OnCriticalHitEnter(_numberOfModule);
                }
            }
        }

        public void Fix()
        {
            _isBroken = false;
        }
    }
}