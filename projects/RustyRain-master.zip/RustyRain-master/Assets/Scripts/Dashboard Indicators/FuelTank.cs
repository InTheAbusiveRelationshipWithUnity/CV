﻿using UnityEngine;

public class FuelTank : MonoBehaviour
{
    [SerializeField] private Dashboard _dashboard;

    [SerializeField] private float _tankCapacity = 360000f; // Уровень топлива
    public float _currentFuelQuantity;

    public bool fuelIsOver;

    private void Start()
    {
        _currentFuelQuantity = _tankCapacity;
        fuelIsOver = false;
    }

    public void BurnFuel(float quantity)
    {
        _currentFuelQuantity -= quantity;

        if ( _currentFuelQuantity <= 0 )
            fuelIsOver = true;
        
        if (_dashboard.isActiveAndEnabled)
            _dashboard.fuel.UpdateFuel(_currentFuelQuantity);
    }
}