using UnityEngine.UI;
using UnityEngine;
using System.Collections;

public class LevelManager : MonoBehaviour
{
    [SerializeField] private Transform _startPos;
    [SerializeField] private Transform _endPos;

    [SerializeField] private Slider _mapLine;

    [SerializeField] private Animator _screenAnimation;

    [SerializeField] private Transform _player;

    private void Start()
    {
        _screenAnimation.Play("StartScreenAnimation");
        StartCoroutine(StartLevel());
    }

    private void Update()
    {
        _mapLine.value = (-_startPos.position.x + _player.position.x) / _endPos.position.x;
    }

    private IEnumerator StartLevel()
    {
        yield return new WaitForSeconds(0.045f);
    }
}
