using UnityEngine;

public class Dashboard : MonoBehaviour
{
    public class Instrumentation
    {
        public Transform axisOfArrayRotation;

        private float minimumAngle;
        public float MinumumAngle
        {
            get { return minimumAngle; }
        }
        private float maximumAngle;
        public float MaximumAngle
        {
            get { return maximumAngle; }
        }

        public Instrumentation(float minimumAngle, float maximumAngle, Transform dashboardTransform, string arrowsObjectName)
        {
            this.minimumAngle = minimumAngle;
            this.maximumAngle = maximumAngle;
            GetPanelArrow(dashboardTransform, arrowsObjectName);
        }

        public void SetAngles(float minimum, float maximum)
        {
            minimumAngle = minimum;
            maximumAngle = maximum;
        }

        public void GetPanelArrow(Transform dashboardTransform, string name)
        {
            Transform arrowsParent = null;
            float countOfPanels;

            arrowsParent = dashboardTransform.GetChild(0);
            countOfPanels = arrowsParent.childCount;

            for (int i = 0; i < countOfPanels; i++)
            {
                Transform currentChild = arrowsParent.GetChild(i);
                if (currentChild.name == name)
                {
                    axisOfArrayRotation = currentChild;
                }
            }
        }
    }
    
    public class Toggle
    {
        public Transform axisOfArrayRotation;

        private float minimumAngle;
        public float MinumumAngle
        {
            get { return minimumAngle; }
        }
        private float maximumAngle;
        public float MaximumAngle
        {
            get { return maximumAngle; }
        }

        public Toggle(float minimumAngle, float maximumAngle, Transform dashboardTransform, string arrowsObjectName)
        {
            this.minimumAngle = minimumAngle;
            this.maximumAngle = maximumAngle;
            GetPanelArrow(dashboardTransform, arrowsObjectName);
        }

        public void SetAngles(float minimum, float maximum)
        {
            minimumAngle = minimum;
            maximumAngle = maximum;
        }

        public void GetPanelArrow(Transform dashboardTransform, string name)
        {
            Transform arrowsParent = null;
            float countOfPanels;

            arrowsParent = dashboardTransform.GetChild(0);
            countOfPanels = arrowsParent.childCount;

            for (int i = 0; i < countOfPanels; i++)
            {
                Transform currentChild = arrowsParent.GetChild(i);
                if (currentChild.name == name)
                {
                    axisOfArrayRotation = currentChild;
                }
            }
        }
    }

    public class Button
    {
        bool pressed;
    }

    public class Speedometer : Instrumentation
    {
        private float _currentSpeed;
        private float _maximumSpeed;
        private float _minimumSpeed;

        public float CurrentSpeed
        {
            get
            {
                return this._currentSpeed;
            }
        }
        public float MaximumSpeed
        {
            get
            {
                return this._maximumSpeed;
            }
        }

        public Speedometer(float minimumSpeed, float maximumSpeed, float minimumAngle, float maximumAngle, Transform dashboardTransform, string arrowsObjectName) : base(minimumAngle, maximumAngle, dashboardTransform, arrowsObjectName)
        {
            SetSpeedLimits(minimumSpeed, maximumSpeed);
        }

        public void UpdateSpeed(float currentValue)
        {
            _currentSpeed = Mathf.Clamp(currentValue, _minimumSpeed, _maximumSpeed);
        }

        private void SetSpeedLimits(float minimum, float maximum)
        {
            _minimumSpeed = minimum;
            _maximumSpeed = maximum;
        }
    }

    public class Tachometer : Instrumentation
    {
        private float _currentRPM;
        private float _maximumRPM;
        private float _minimumRPM;

        public float CurrentRPM
        {
            get
            {
                return this._currentRPM;
            }
        }
        public float MaximumRPM
        {
            get
            {
                return this._maximumRPM;
            }
        }

        public Tachometer(float minimumRPM, float maximumRPM, float minimumAngle, float maximumAngle, Transform dashboardTransform, string arrowsObjectName) : base(minimumAngle, maximumAngle, dashboardTransform, arrowsObjectName)
        {
            SetRPMLimits(minimumRPM, maximumRPM);
        }

        public void UpdateRPM(float currentValue)
        {
            _currentRPM = Mathf.Clamp(currentValue, _minimumRPM, _maximumRPM);
        }

        private void SetRPMLimits(float minimum, float maximum)
        {
            _minimumRPM = minimum;
            _maximumRPM = maximum;
        }
    }

    public Speedometer speedometer;
    public Tachometer tachometer;
    public Fuel fuel;
    public Temperature temp;
    public PhaseSwitsh phaseSwitsh;
    public Voltmeter voltmeter;
    public FuelSwap fuelSwap;
    public Oil oil;

    private void Awake()
    {
        speedometer = new Speedometer(0, 60, -135, 135, transform, "Speedometer");
        tachometer = new Tachometer(0, 4000, -135, 135, transform, "Tachometer");
        fuel = new Fuel(0, 360000, 83, -83, transform, "Fuel");
        temp = new Temperature(0, 500, 0, 360, transform, "Temperature");
        phaseSwitsh = new PhaseSwitsh(0, 1, -25, 22, transform, "PhaseSwitch");
        voltmeter = new Voltmeter(0, 2000, 37, -37, transform, "Voltmeter");
        fuelSwap = new FuelSwap(0, 2000, 90, -90, transform, "FuelSwap");
        oil = new Oil(0, 900, 62, -62, transform, "Oil");
    }

    public class Fuel : Instrumentation
    {
        private float _minimumFuel;
        private float _maximumFuel;
        private float _currentFuel;

        public float CurrentFuel
        {
            get { return _currentFuel; }
        }

        public float MaximumFuel
        {
            get { return _maximumFuel; }
        }

        public Fuel(float _minimumFuel, float _maximumFuel, float minimumAngle, float maximumAngle, Transform dashboardTransform, string arrowsObjectName)
            : base(minimumAngle, maximumAngle, dashboardTransform, arrowsObjectName)
        {
            SetFuelLimits(_minimumFuel, _maximumFuel);
        }

        private void SetFuelLimits(float minimumFuel, float maximumFuel)
        {
            _minimumFuel = minimumFuel;
            _maximumFuel = maximumFuel;
        }

        public void UpdateFuel(float value)
        {
            _currentFuel = Mathf.Clamp(value, _minimumFuel, _maximumFuel);
        }
    }

    public class Temperature : Instrumentation
    {
        private float _minimumTemp;
        private float _maximumTemp;
        private float _currentTemp;

        public float CurrentTemp
        {
            get { return _currentTemp; }
        }

        public float MaximumTemp
        {
            get { return _maximumTemp; }
        }

        public Temperature(float _minimumFuel, float _maximumFuel, float minimumAngle, float maximumAngle, Transform dashboardTransform, string arrowsObjectName)
            : base(minimumAngle, maximumAngle, dashboardTransform, arrowsObjectName)
        {
            SetTempLimits(_minimumFuel, _maximumFuel);
        }

        private void SetTempLimits(float minimumFuel, float maximumFuel)
        {
            _minimumTemp = minimumFuel;
            _maximumTemp = maximumFuel;
        }

        public void UpdateTemp(float value)
        {
            _currentTemp = Mathf.Clamp(value, _minimumTemp, _maximumTemp);
        }
    }
    public class PhaseSwitsh : Instrumentation
    {
        public PhaseSwitsh(float _minimumWater, float _maximumWater, float minimumAngle, float maximumAngle, Transform dashboardTransform, string arrowsObjectName)
            : base(minimumAngle, maximumAngle, dashboardTransform, arrowsObjectName)
        {
        }
    }

    public class Voltmeter : Instrumentation
    {
        private float _minimumValue;
        private float _maximumValue;
        private float _currentValue;

        public float CurrentValue
        {
            get { return _currentValue; }
        }
        public float MaximumValue
        {
            get { return _maximumValue; }
        }

        public Voltmeter(float _minimumVolt, float _maximumVolt, float minimumAngle, float maximumAngle, Transform dashboardTransform, string arrowsObjectName)
            : base(minimumAngle, maximumAngle, dashboardTransform, arrowsObjectName)
        {
            _minimumValue = _minimumVolt;
            _maximumValue = _maximumVolt;
        }

        public void UpdateValue(float value)
        {
            _currentValue = Mathf.Clamp(value, _minimumValue, _maximumValue);
        }
    }

    public class FuelSwap : Instrumentation
    {
        private float _minimumValue;
        private float _maximumValue;
        private float _currentValue;

        public float CurrentValue
        {
            get { return _currentValue; }
        }

        public float MaximumValue
        {
            get { return _maximumValue; }
        }

        public FuelSwap(float minimumValue, float maximumValue, float minimumAngle, float maximumAngle, Transform dashboardTransform, string arrowsObjectName)
            : base(minimumAngle, maximumAngle, dashboardTransform, arrowsObjectName)
        {
            _minimumValue = minimumValue;
            _maximumValue = maximumValue;
        }

        public void UpdateValue(float value)
        {
            _currentValue = Mathf.Clamp(value, _minimumValue, _maximumValue);
        }
    }

    public class Oil : Instrumentation
    {
        private float _minimumValue;
        private float _maximumValue;
        private float _currentValue;

        public float CurrentValue
        {
            get { return _currentValue; }
        }
        public float MaximumValue
        {
            get { return _maximumValue; }
        }

        public Oil(float minimumValue, float maximumValue, float minimumAngle, float maximumAngle, Transform dashboardTransform, string arrowsObjectName)
            : base(minimumAngle, maximumAngle, dashboardTransform, arrowsObjectName)
        {
            _minimumValue = minimumValue;
            _maximumValue = maximumValue;
            SetFuelLimits(_minimumValue, _maximumValue);
        }

        private void SetFuelLimits(float minimumFuel, float maximumFuel)
        {
            _minimumValue = minimumFuel;
            _maximumValue = maximumFuel;
        }
        public void UpdateValue(float value)
        {
            _currentValue = Mathf.Clamp(value, _minimumValue, _maximumValue);
        }
    }
}