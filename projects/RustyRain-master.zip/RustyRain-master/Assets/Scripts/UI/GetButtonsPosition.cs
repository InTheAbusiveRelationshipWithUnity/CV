using UnityEngine;

public class GetButtonsPosition : MonoBehaviour
{
    [SerializeField] private RectTransform[] _pos;

    private void Start()
    {
        _pos[0].anchoredPosition = new Vector2(PlayerPrefs.GetFloat("DashboardX"), PlayerPrefs.GetFloat("DashboardY"));
        _pos[1].anchoredPosition = new Vector2(PlayerPrefs.GetFloat("LeverX"), PlayerPrefs.GetFloat("LeverY"));
        _pos[2].anchoredPosition = new Vector2(PlayerPrefs.GetFloat("MapLineX"), PlayerPrefs.GetFloat("MapLineY"));
        _pos[3].anchoredPosition = new Vector2(PlayerPrefs.GetFloat("ZoomButtonX"), PlayerPrefs.GetFloat("ZoomButtonY"));
        _pos[4].anchoredPosition = new Vector2(PlayerPrefs.GetFloat("FireButtonX"), PlayerPrefs.GetFloat("FireButtonY"));
        _pos[5].anchoredPosition = new Vector2(PlayerPrefs.GetFloat("ChaingunButtonX"), PlayerPrefs.GetFloat("ChaingunButtonY"));
        _pos[6].anchoredPosition = new Vector2(PlayerPrefs.GetFloat("ModulesBarX"), PlayerPrefs.GetFloat("ModulesBarY"));
        _pos[7].anchoredPosition = new Vector2(PlayerPrefs.GetFloat("AmmunitionPanelX"), PlayerPrefs.GetFloat("AmmunitionPanelY"));
        _pos[8].anchoredPosition = new Vector2(PlayerPrefs.GetFloat("SettingsButtonX"), PlayerPrefs.GetFloat("SettingsButtonY"));
        _pos[9].anchoredPosition = new Vector2(PlayerPrefs.GetFloat("MechX"), PlayerPrefs.GetFloat("MechY"));
    }
}
