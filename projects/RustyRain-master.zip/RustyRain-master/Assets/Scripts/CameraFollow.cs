using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    [SerializeField] private Transform _leftWall;
    [SerializeField] private Transform _rightWall;

    private Transform player;
    private int lastX;
    private Camera _camera;

    public float damping = 1.5f;
    public Vector2 offset = new Vector2(2f, 1f);

    public bool faceLeft;
    public bool isActive = false;
    public bool freezeYAxe = false;

    private void Start()
    {
        _camera = GetComponent<Camera>();
    }

    public void FindPlayer(bool playerFaceLeft)
    {
        player = GameObject.FindGameObjectWithTag("Player").transform;
        lastX = Mathf.RoundToInt(player.position.x);

        if (playerFaceLeft)
        {
            transform.position = new Vector3(player.position.x - offset.x, player.position.y + offset.y + transform.position.y - (freezeYAxe ? player.position.y + offset.y : transform.position.y), transform.position.z);
        }
        else
        {
            transform.position = new Vector3(player.position.x + offset.x, player.position.y + offset.y + transform.position.y - (freezeYAxe ? player.position.y + offset.y : transform.position.y), transform.position.z);
        }
    }

    private void FixedUpdate()
    {
        if (player && isActive)
        {
            int currentX = Mathf.RoundToInt(player.position.x);
            if (currentX > lastX) faceLeft = false; else if (currentX < lastX) faceLeft = true;
            lastX = Mathf.RoundToInt(player.position.x);

            Vector3 target;
            if (player.position.x > _leftWall.position.x + _camera.orthographicSize * _camera.aspect + (faceLeft ? 0 : offset.x) && player.position.x < _rightWall.position.x - _camera.orthographicSize * _camera.aspect - (faceLeft ? 0 : offset.x))
            {
                if (faceLeft)
                {
                    target = new Vector3(player.position.x - offset.x, player.position.y + offset.y + transform.position.y - (freezeYAxe ? player.position.y + offset.y : transform.position.y), transform.position.z);
                }
                else
                {
                    target = new Vector3(player.position.x + offset.x, player.position.y + offset.y + transform.position.y - (freezeYAxe ? player.position.y + offset.y : transform.position.y), transform.position.z);
                }
                Vector3 currentPosition = Vector3.Lerp(transform.position, target, damping * Time.deltaTime);
                transform.position = currentPosition;
            }
        }
        else if (isActive)
        {
            offset = new Vector2(Mathf.Abs(offset.x), offset.y);
            FindPlayer(faceLeft);
        }
    }
}
