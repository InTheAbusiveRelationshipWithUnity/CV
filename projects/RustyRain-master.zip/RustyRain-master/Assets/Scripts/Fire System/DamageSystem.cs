using System;
using System.Collections;
using UnityEngine;

public class DamageSystem : MonoBehaviour
{
    [SerializeField] private SpriteRenderer _modulePanel;
    [SerializeField] private Sprite[] _modules;

    private int _numberOfDiedCrue = 0;

    public Action ammunitionWasExploded;
    public Action tankWasDestroyed;

    private void Start()
    {
        _modulePanel.color = new Color(1, 1, 1, 0);
    }

    public void OnCriticalHitEnter(bool isCriticalHit, int numberOfModule)
    {
        StartCoroutine(ExecuteSpriteChange(isCriticalHit, numberOfModule));

        if (numberOfModule == 1)
        {
            ammunitionWasExploded?.Invoke();
            tankWasDestroyed?.Invoke();
        }
        else if (numberOfModule >= 2)
            _numberOfDiedCrue++;
        
        if (_numberOfDiedCrue >= 4)
        {
            tankWasDestroyed?.Invoke();
        }
    }

    private IEnumerator ExecuteSpriteChange(bool isCriticalHit, int numberOfModule)
    {
        _modulePanel.sprite = _modules[numberOfModule];
        _modulePanel.gameObject.SetActive(true);

        if (isCriticalHit)
            _modulePanel.color = new Color(1, 0, 0, 1);
        else
            _modulePanel.color = new Color(1, 1, 1, 1);

        for (float f = 1f; f >= -0.05f; f -= 0.05f)
        {
            Color color = _modulePanel.color;
            color.a = f;
            _modulePanel.color = color;
            yield return new WaitForSeconds(0.05f);
        }
    }
}
