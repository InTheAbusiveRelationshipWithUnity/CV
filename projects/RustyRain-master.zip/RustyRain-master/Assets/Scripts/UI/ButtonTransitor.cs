using UnityEngine;

public class ButtonTransitor : MonoBehaviour
{
    [SerializeField] private Rigidbody2D _rb;

    private float _xRange;
    private float _yRange;

    private Vector2 _lastPos;

    private bool _isMobilePlatform;

    private RectTransform rect;

    private Vector2 velocity = Vector2.zero;
    private void Start()
    {
        _isMobilePlatform = Application.isMobilePlatform;

        rect = transform as RectTransform;
    }

    private void FixedUpdate()
    {
        _rb.MovePosition(_rb.position + velocity * Time.fixedDeltaTime);
        velocity = Vector2.zero;
    }

    public void Move()
    {  
        if (!_isMobilePlatform)
        {
            velocity = new Vector2(Input.mousePosition.x - _lastPos.x, Input.mousePosition.y - _lastPos.y) * 0.45f;
            _lastPos = Input.mousePosition;
        }
        else
        {
            velocity = new Vector2(Input.GetTouch(0).position.x - _lastPos.x, Input.GetTouch(0).position.y - _lastPos.y) * 0.45f;
            _lastPos = Input.GetTouch(0).position;
        }

        //rect.anchoredPosition = new Vector3(pos.x + _xRange, pos.y - _camera.pixelHeight + _yRange, transform.position.z);
    }

    public void Begin()
    {
        _lastPos = Input.mousePosition;

        _rb.bodyType = RigidbodyType2D.Dynamic;
    }

    public void End()
    {
        _rb.bodyType = RigidbodyType2D.Kinematic;
    }
}
