using System;
using UnityEngine;
using UnityEngine.UI;

public class ModulesBar : MonoBehaviour
{
    [SerializeField] private Image[] modulesIcons;

    private int _numberOfDiedCrue = 0;

    public Action ammunitionWasExploded;
    public Action tankWasDestroyed;

    public void OnHitEnter(int numberOfModule)
    {
        if (modulesIcons[numberOfModule].color != Color.red)
        {
            modulesIcons[numberOfModule].gameObject.SetActive(true);
            modulesIcons[numberOfModule].color = Color.white;
        }
    }

    public void OnCriticalHitEnter(int numberOfModule)
    {
        modulesIcons[numberOfModule].gameObject.SetActive(true);
        modulesIcons[numberOfModule].color = Color.red;

        if (numberOfModule == 1)
        {
            ammunitionWasExploded?.Invoke();
            tankWasDestroyed?.Invoke();
        }
        else if (numberOfModule >= 2)
            _numberOfDiedCrue++;

        if (_numberOfDiedCrue >= 4)
        {
            tankWasDestroyed?.Invoke();
        }
    }

    public void TurnOffCrewIcons()
    {
        modulesIcons[3].gameObject.SetActive(false);
    }

    public void TurnOffModulesIcons()
    {
        for (int i = 0; i < modulesIcons.Length; i++)
        {
            if (i != 3)
                modulesIcons[i].gameObject.SetActive(false);
        }
    }
}
