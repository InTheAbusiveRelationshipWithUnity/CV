using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class MechanismOfDecklination : MonoBehaviour
{
    private Camera _camera;
    private Vector3 _screenPos; // ������� ������� ������ ��� �������-����������
    private Vector2 _pos; // ������� ������� ������ ��� ���������� ����������
    private float angleOffset; // ��������� ���� �������� ������
    private float angle; // ������� ���� 
    private float _oldAngle; // ���� �������� �����

    private bool isEnter = false; // �������� �� ���������� �������/������ �� ������
    private int _currentTouchCount;
    private float _currentAngle = 0; // ������� ���� ������� ������
    private bool _isRotating = false; // �������� �� ��, ���������� �� ��������
    private bool _isLeftRotation; // ����������� ����������� ��������

    private bool _isMobilePlatform = false;

    public Transform weapon;
    public Transform chainGun;
    public Transform tankPos;

    public Tank tank;

    private void Start()
    {
        _camera = Camera.main;

        if (Application.isMobilePlatform)
            _isMobilePlatform = true;
    }

    private void Update()
    {
        Debug.Log(Camera.main.WorldToScreenPoint(transform.position));
        if (Input.GetMouseButtonDown(0))
        {
            if (isEnter)
            {
                if (!_isMobilePlatform)
                {
                    _screenPos = _camera.WorldToScreenPoint(transform.position);
                    Vector3 vec3 = Input.mousePosition - _screenPos;
                    angleOffset = (Mathf.Atan2(transform.right.y, transform.right.x) - Mathf.Atan2(vec3.y, vec3.x)) * Mathf.Rad2Deg;
                }
                else
                {
                    _pos = _camera.WorldToScreenPoint(transform.position);

                    for (int i = 0; i < Input.touchCount; i++)
                    {
                        if (Input.GetTouch(i).position.x > Camera.main.WorldToScreenPoint(transform.position).x - 430 && Input.GetTouch(i).position.x < Camera.main.WorldToScreenPoint(transform.position).x + 430
                            && Input.GetTouch(i).position.y > Camera.main.WorldToScreenPoint(transform.position).y - 270 && Input.GetTouch(i).position.y < Camera.main.WorldToScreenPoint(transform.position).y + 270)
                        {
                            PointerEventData eventData = new PointerEventData(EventSystem.current);

                            eventData.position = Input.GetTouch(i).position;

                            List<RaycastResult> results = new List<RaycastResult>();
                            EventSystem.current.RaycastAll(eventData, results);

                            if (results.Count > 0)
                            {
                                _currentTouchCount = i;
                                Vector2 vec2 = Input.GetTouch(_currentTouchCount).position - _pos;
                                angleOffset = (Mathf.Atan2(transform.right.y, transform.right.x) - Mathf.Atan2(vec2.y, vec2.x)) * Mathf.Rad2Deg;
                                break;
                            }
                        }
                    }
                }
            }
        }
        if (Input.GetMouseButton(0))
        {
            if (isEnter)
            {
                if (!_isMobilePlatform)
                {
                    Vector3 vec3 = Input.mousePosition - _screenPos;
                    angle = Mathf.Atan2(vec3.y, vec3.x) * Mathf.Rad2Deg;
                    if ((_isLeftRotation && (weapon.localRotation.z * 113 <= 16)) || (!_isLeftRotation && (weapon.localRotation.z * 113 >= -6))) // localRotation.z * 113 ������ ��� ���������������� �������� �� ������������ � ������� ������
                        transform.localRotation = Quaternion.Euler(0, 0, angle + angleOffset);
                }
                else
                {
                    for (int i = 0; i < Input.touchCount; i++)
                    {
                        if (Input.GetTouch(i).position.x > Camera.main.WorldToScreenPoint(transform.position).x - 430 && Input.GetTouch(i).position.x < Camera.main.WorldToScreenPoint(transform.position).x + 430
                            && Input.GetTouch(i).position.y > Camera.main.WorldToScreenPoint(transform.position).y - 270 && Input.GetTouch(i).position.y < Camera.main.WorldToScreenPoint(transform.position).y + 270)
                        {
                            PointerEventData eventData = new PointerEventData(EventSystem.current);

                            eventData.position = Input.GetTouch(i).position;

                            List<RaycastResult> results = new List<RaycastResult>();
                            EventSystem.current.RaycastAll(eventData, results);

                            if (results.Count > 0)
                            {
                                _currentTouchCount = i;
                                Vector2 vec2 = Input.GetTouch(_currentTouchCount).position - _pos;
                                angle = Mathf.Atan2(vec2.y, vec2.x) * Mathf.Rad2Deg;
                                if ((_isLeftRotation && (weapon.localRotation.z * 113 <= 16)) || (!_isLeftRotation && (weapon.localRotation.z * 113 >= -6)))
                                    transform.localRotation = Quaternion.Euler(0, 0, angle + angleOffset);
                                break;
                            }
                        }
                    }
                }
            }
        }

        if (Input.GetMouseButtonUp(0))
            isEnter = false;

        if (transform.eulerAngles.z - _currentAngle > 0 && angle > _oldAngle)
        {
            _isLeftRotation = true;
            _isRotating = true;
        }
        else if (transform.eulerAngles.z - _currentAngle < 0 && angle < _oldAngle)
        {
            _isLeftRotation = false;
            _isRotating = true;
        }
        else if (transform.eulerAngles.z == _currentAngle && angle > _oldAngle && !(weapon.eulerAngles.z > tankPos.rotation.z * 113 + 354 || weapon.eulerAngles.z < tankPos.rotation.z * 113 + 17))
        {
            _isLeftRotation = true;
            _isRotating = true;
        }
        else if (transform.eulerAngles.z == _currentAngle && angle < _oldAngle && !(weapon.eulerAngles.z < tankPos.rotation.z * 113 + 16 || weapon.eulerAngles.z > tankPos.rotation.z * 113 + 340))
        {
            _isLeftRotation = false;
            _isRotating = true;
        }
        else
            _isRotating = false;

        if (_isLeftRotation && _isRotating)
        {
            if (weapon.localRotation.z * 113 <= 16)
                weapon.localRotation = Quaternion.Euler(0, 0, weapon.localEulerAngles.z + tank.AimSpeed * (Mathf.Abs(_currentAngle - transform.eulerAngles.z) / 55));
            if (chainGun != null && chainGun.localRotation.z * 113 <= 10)
                chainGun.localRotation = Quaternion.Euler(0, 0, chainGun.localEulerAngles.z + tank.AimSpeed * (Mathf.Abs(_currentAngle - transform.eulerAngles.z) / 55));
        }
        else if (!_isLeftRotation && _isRotating)
        {
            if ((weapon.localRotation.z * 113 != -5.913963f) || weapon.localEulerAngles.z < 300)
                weapon.localRotation = Quaternion.Euler(0, 0, weapon.localEulerAngles.z - tank.AimSpeed * (Mathf.Abs(_currentAngle - transform.eulerAngles.z) / 55));
            if (chainGun != null && chainGun.localEulerAngles.z < 350)
                chainGun.localRotation = Quaternion.Euler(0, 0, chainGun.localEulerAngles.z - tank.AimSpeed * (Mathf.Abs(_currentAngle - transform.eulerAngles.z) / 55));
        }

        _currentAngle = transform.eulerAngles.z;
        _oldAngle = angle;

        if (weapon.localRotation.z * 113 > 16)
            weapon.localRotation = Quaternion.Euler(0, 0, 16);
        else if (weapon.localEulerAngles.z > 200 && weapon.localRotation.z * 113 * -1 < -6)
            weapon.localRotation = Quaternion.Euler(0, 0, -6);
    }

    public void ChangeBoolToTrue()
    {
        isEnter = true;
    }
}