using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class LevelLoader : MonoBehaviour
{
    [SerializeField] private GameObject[] objectsOn;
    [SerializeField] private Animator screenAnimator;

    [SerializeField] private GameObject _onClickImage;

    public int levelOnQueue;

    private void Start()
    {
        levelOnQueue = PlayerPrefs.GetInt("LevelOnQueue");

        _onClickImage.SetActive(false);
    }

    public void StartDrive()
    {
        ShowPanels(true);
        //StartCoroutine(ActivateAndDisactivateImage());
    }

    IEnumerator SkipScreen()
    {
        ShowPanels(false);

        screenAnimator.Play("ScreenSkipAnimation");
        yield return new WaitForSeconds(0.45f);

        SceneManager.LoadScene(levelOnQueue);
    }

    private void ShowPanels(bool actOrNot)
    {
        for (int i = 0; i < objectsOn.Length; i++)
        {
            objectsOn[i].SetActive(actOrNot);
        }
    }

    private IEnumerator ActivateAndDisactivateImage()
    {
        _onClickImage.SetActive(true);
        yield return new WaitForSeconds(0.5f);
        _onClickImage.SetActive(false);
    }

    private void OnTriggerEnter2D(Collider2D collider)
    {
        if (collider.CompareTag("PlayerTank"))
        {
            StartCoroutine(SkipScreen());
        }
    }
}