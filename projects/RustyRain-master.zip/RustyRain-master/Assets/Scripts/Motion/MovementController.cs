using UnityEngine;

public class MovementController : MonoBehaviour
{
    public static MovementController instance;

    private float targetSpeed = 0f;
    private float currentSpeed = 0f;

    private float _fuelConsumption;

    public float _currentRPM;
    private float _maxRPM = 3600f;
    private float _minRPM = 0f;
    private int _currentGear; // ������� ��������
    private bool _IsUpper = true; // �������� �������� ��������� �������� ��������� �� ������� ��������
    private float _currentPos;

    public float movement = 0f;
    [SerializeField] private AnimationCurve acceleration; // �������� ��������� �������
    [SerializeField] private float stoppingInfelicityFactor; // ����������� ���������

    [SerializeField] private float _maxTorque = 10000f; // ������������ �������� ������

    [SerializeField] private WheelJoint2D[] wheels;
    [SerializeField] private TurningTheHandle motionHandlerController;
    [SerializeField] private Dashboard dashboard;

    [SerializeField] private ParticleSystem[] _groundEffects;

    [SerializeField] private Tank _tank;

    private Rigidbody2D body;
    private JointMotor2D _motor;

    private bool _engineWasStarted = false;

    public FuelTank fuel;

    [HideInInspector] public bool canDrive;

    private void Start()
    {
        _currentPos = transform.position.x;
    }

    private void OnEnable()
    {
        EngineStart.engineIsStarted += CheckEngineIsStarted;
    }
    private void OnDisable()
    {
        EngineStart.engineIsStarted -= CheckEngineIsStarted;
    }

    private void Update()
    {
        Move();
        CountToBurnFuelAndTachometrMetrics();
    }

    private void FixedUpdate()
    {
        _currentPos = transform.position.x;

        if (_engineWasStarted)
        {
            if (movement == 0f)
            {
                targetSpeed = 0f;
            }
            else if (movement != 0 && canDrive)
            {
                targetSpeed = Mathf.Clamp(targetSpeed + movement * Time.deltaTime, -_tank.MaxSpeed, _tank.MaxSpeed);

                TurnTheEffect();
            }
            currentSpeed = Mathf.MoveTowards(currentSpeed, targetSpeed, acceleration.Evaluate(targetSpeed) * 8f);
            ApplySpeedToWheels(currentSpeed);

            if (dashboard.gameObject.activeSelf)
            {
                dashboard.speedometer.UpdateSpeed(body.velocity.magnitude * 5.2f);
            }
        }
    }

    private void Awake()
    {
        if (instance == null)
            instance = this;

        fuel = GetComponent<FuelTank>();
        body = GetComponent<Rigidbody2D>();
        SetAccelerationKeys();
    }

    private void SetAccelerationKeys()
    {
        acceleration = new AnimationCurve();
        acceleration.AddKey(new Keyframe(-_tank.MaxSpeed, 0.2f));
        acceleration.AddKey(new Keyframe(0, 0.8f));
        acceleration.AddKey(new Keyframe(-_tank.MaxSpeed, 0.2f));
    }

    private void Move()
    {
        if (!fuel.fuelIsOver && _engineWasStarted)
        {
            movement = GetNormalizedAngle(motionHandlerController.GetCurrentAngle(), motionHandlerController.GetNormalizationFactor()) * _tank.MaxSpeed;
            _fuelConsumption += Mathf.Abs(GetNormalizedAngle(motionHandlerController.GetCurrentAngle(), motionHandlerController.GetNormalizationFactor())) * 10 + 0.01f;

            if (_currentRPM < _maxRPM && movement != 0f && Mathf.Abs(transform.position.x - _currentPos) > 0.01f)
            {
                _currentRPM += Mathf.Abs(GetNormalizedAngle(motionHandlerController.GetCurrentAngle(), motionHandlerController.GetNormalizationFactor())) * 3;
            }
            if (_currentRPM > _minRPM && movement == 0f && Mathf.Abs(transform.position.x - _currentPos) < 0.001f)
            {
                _currentRPM -= 50f;
                _currentGear = 0;

                foreach (var i in _groundEffects)
                {
                    i.gameObject.SetActive(false);
                }
            }

            if (_currentRPM >= 2000f && _currentGear < 5)
            {
                _currentRPM = 0f;
                _currentGear += 1;

            }

            if (_currentRPM > 3400f && _IsUpper)
            {
                _currentRPM -= 100f;
            }
            _IsUpper = !_IsUpper;
        }
    }

    private void ApplySpeedToWheels(float speed)
    {
        for (int i = 0; i < wheels.Length; i++)
        {
            _motor.motorSpeed = speed;
            _motor.maxMotorTorque = _maxTorque;
            wheels[i].useMotor = true;
            wheels[i].motor = _motor;
        }
    }

    public float GetNormalizedAngle(float angle, float normalizationFactor)
    {
        float normalizedAngle = angle / normalizationFactor;
        if ((0 <= normalizedAngle && normalizedAngle <= stoppingInfelicityFactor) || (normalizedAngle <= 0 && normalizedAngle >= -stoppingInfelicityFactor))
        {
            return 0;
        }
        else
        {
            return normalizedAngle;
        }
    }

    private void CountToBurnFuelAndTachometrMetrics()
    {
        fuel.BurnFuel(_fuelConsumption);
        _fuelConsumption = 0;

        if (dashboard.isActiveAndEnabled)
            dashboard.tachometer.UpdateRPM(_currentRPM);
    }

    private void CheckEngineIsStarted()
    {
        _engineWasStarted = true;
    }

    [System.Obsolete]
    private void TurnTheEffect()
    {
        float slantMultiplier = 0f;

        if (transform.localRotation.z < 0)
            slantMultiplier = Mathf.Abs(transform.localRotation.z) * 8;

        for (int i = 0; i < _groundEffects.Length; i++) 
        {

            _groundEffects[i].gameObject.SetActive(true);
            _groundEffects[i].startLifetime = Mathf.Abs(movement) / 1000 - 1 + 0.4f * i;
            _groundEffects[i].startSpeed = Mathf.Abs(movement) / 100 + slantMultiplier;
            _groundEffects[i].emissionRate = Mathf.Abs(movement) / 100 * 1.2f + slantMultiplier;
        }
    }
}