using UnityEngine;

public class TankExplosion : MonoBehaviour
{
    [SerializeField] private Rigidbody2D _turret;

    private float _forceOfExplosion = 65f;

    public void ExplosionOfAmmunition()
    {
        _turret.bodyType = RigidbodyType2D.Dynamic;

        _turret.AddForce(_turret.transform.up * _forceOfExplosion, ForceMode2D.Impulse);
        _turret.AddForce(_turret.transform.right * _forceOfExplosion / 3, ForceMode2D.Impulse);
        _turret.AddTorque(-1150);
    }
}
