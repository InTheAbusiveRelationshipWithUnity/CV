using System;
using System.Collections;
using UnityEngine;

public class EngineStart : MonoBehaviour
{
    [SerializeField] private Dashboard _dashboard;

    [SerializeField] private GameObject[] _lights;
    [SerializeField] private GameObject[] _imagesIfButtonPressed;

    [SerializeField] private Transform _effectsPos;
    [SerializeField] private ParticleSystem _smokeEffect;
    [SerializeField] private ParticleSystem _startSmokeEffect;

    [SerializeField] private AudioSource _audioSourceForButtons;
    [SerializeField] private AudioSource _audioSourceForVoltmeter;
    [SerializeField] private AudioSource _audioSourceForFuelSwap;

    [SerializeField] private bool _onLevel = false;

    private ParticleSystem _effect;
    private ParticleSystem _startEffect;

    private float _currentVoltmeterValue = 0;
    private float _currentFuelValue = 0;
    private bool _swapIsActive = false;

    public static Action engineIsStarted;

    private void Start()
    {
        _lights[0].SetActive(true); _lights[1].SetActive(false);

        if (_onLevel)
        {
            StartEngine();
            _currentFuelValue = 2000f;
            _swapIsActive = true;
            _currentVoltmeterValue = 900f;
        }
    }

    private void Update()
    {
        if (_currentFuelValue > 1900f)
        {
            _lights[0].SetActive(false);
            _lights[1].SetActive(true);
        }
        else
        {
            _lights[0].SetActive(true);
            _lights[1].SetActive(false);
        }

        _audioSourceForButtons.volume = Settings.instance.soundsVolume;
        _audioSourceForFuelSwap.volume = Settings.instance.soundsVolume;
        _audioSourceForVoltmeter.volume = Settings.instance.soundsVolume;
    }

    private void FixedUpdate()
    {
        if (_dashboard.isActiveAndEnabled)
        {
            if (_dashboard.phaseSwitsh.axisOfArrayRotation.eulerAngles.z >= 0 && _dashboard.phaseSwitsh.axisOfArrayRotation.eulerAngles.z < 300 && _currentVoltmeterValue < 2000)
            {
                _currentVoltmeterValue += 1f;
                _dashboard.voltmeter.UpdateValue(_currentVoltmeterValue);
            }
            else if (_dashboard.phaseSwitsh.axisOfArrayRotation.eulerAngles.z > 300 && _currentVoltmeterValue > 0)
            {
                _currentVoltmeterValue -= 0.5f;
                _dashboard.voltmeter.UpdateValue(_currentVoltmeterValue);
            }

            if (_swapIsActive && _currentFuelValue <= 2000f)
            {
                _currentFuelValue += 2f;
                _dashboard.fuelSwap.UpdateValue(_currentFuelValue);
            }
            else if (_swapIsActive && _currentFuelValue >= 2000f)
            {
                _swapIsActive = false;
                _audioSourceForFuelSwap.Stop();
            }
            
        }
        
        if (_effect != null)
            _effect.transform.position = _effectsPos.position;
        if (_startSmokeEffect != null)
            _startSmokeEffect.transform.position = _effectsPos.position;
    }

    public void PhaseSwitch()
    {
        _audioSourceForButtons.Play();

        if (_dashboard.phaseSwitsh.axisOfArrayRotation.eulerAngles.z >= 0 && _dashboard.phaseSwitsh.axisOfArrayRotation.eulerAngles.z < 300)
        {
            _dashboard.phaseSwitsh.axisOfArrayRotation.eulerAngles = new Vector3(
                _dashboard.phaseSwitsh.axisOfArrayRotation.eulerAngles.x,
                _dashboard.phaseSwitsh.axisOfArrayRotation.eulerAngles.y,
                -25f);
            _audioSourceForVoltmeter.Pause();
        }
        else if (_dashboard.phaseSwitsh.axisOfArrayRotation.eulerAngles.z > 300)
        {
            _dashboard.phaseSwitsh.axisOfArrayRotation.eulerAngles = new Vector3(
               _dashboard.phaseSwitsh.axisOfArrayRotation.eulerAngles.x,
               _dashboard.phaseSwitsh.axisOfArrayRotation.eulerAngles.y,
               22f);
            _audioSourceForVoltmeter.Play();
        }
    }

    public void FuelSwap()
    {
        if (_currentVoltmeterValue > 600f && _currentVoltmeterValue < 1400f)
        {
            _swapIsActive = true;
            _audioSourceForButtons.Play();
            _imagesIfButtonPressed[0].SetActive(true);
            _audioSourceForFuelSwap.Play();
        }
    }

    public void StartEngine()
    {
        if ( /*/_currentFuelValue > 1900f)*/ true)
        {
            engineIsStarted?.Invoke();
            _startEffect = Instantiate(_startSmokeEffect, _effectsPos.position, _effectsPos.rotation);
            _effect = Instantiate(_smokeEffect, _effectsPos.position, _effectsPos.rotation);
        }
    }
}
