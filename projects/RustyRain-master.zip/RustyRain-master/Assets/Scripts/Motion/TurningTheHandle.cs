using UnityEngine;
using UnityEngine.EventSystems;

public class TurningTheHandle : MonoBehaviour, IDragHandler
{
    [Header("Canvas")]
    [SerializeField] private Canvas canvas;

    [Header("Handle Angles Settings")]
    [SerializeField][Range(-180f, 180f)] private float minimumHandleAngle;
    [SerializeField][Range(-180f, 180f)] private float maximumHandleAngle;

    [Header("Handle Components")]
    [SerializeField] private RectTransform handleBase;
    [SerializeField] private GameObject handleRotationObject;

    [Header("Degree offset per frame")]
    [SerializeField] private float targetSpeed = 1f;

    private float targetAngle = 0;
    private float currentAngle = 0;

    public void OnDrag(PointerEventData eventData)
    {
        Vector2 dragPosition = eventData.position / canvas.scaleFactor;
        Vector2 rotationPosition = handleBase.anchoredPosition;
        float distance = (dragPosition - rotationPosition).magnitude;
        float angle = Mathf.Asin((dragPosition.x - rotationPosition.x) / distance) * (180 / Mathf.PI); // Asin ���������� � ��������, ��������� � ������� /* ���, ���� ����������� ������� ��� ����� (Mathf.Rad2Deg) */
        float angleScaleFactor = 180 / (Mathf.Abs(minimumHandleAngle) + maximumHandleAngle);
        float clampedAngle = Mathf.Clamp(-angle / angleScaleFactor, minimumHandleAngle, maximumHandleAngle);

        targetAngle = clampedAngle;
    }

    private void FixedUpdate()
    {
        currentAngle = Mathf.MoveTowards(currentAngle, targetAngle, targetSpeed);

        handleRotationObject.transform.eulerAngles = new Vector3(
            handleRotationObject.transform.eulerAngles.x,
            handleRotationObject.transform.eulerAngles.y,
            currentAngle);
    }

    public float GetCurrentAngle()
    {
        return currentAngle;
    }

    public float GetNormalizationFactor()
    {
        return (maximumHandleAngle + Mathf.Abs(minimumHandleAngle)) / 2;
    }
}
