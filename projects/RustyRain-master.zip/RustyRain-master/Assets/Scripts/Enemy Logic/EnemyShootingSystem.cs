using UnityEngine;

public class EnemyShootingSystem : MonoBehaviour
{
    [SerializeField] private GameObject _weapon;
    [SerializeField] private Transform _firePoint;

    [SerializeField] private GameObject[] _bulletPrefabs;
    [SerializeField] private int _bulletCount;

    [SerializeField] private Tank _tank;

    private float _nextFireTime = 0f;

    public bool canFire;
    private void Update()
    {
        RaycastHit2D hit = Physics2D.Raycast(_firePoint.position, -_firePoint.right, 1000);

        if (hit.collider != null)
        {
            if (hit.collider.CompareTag("Player"))
            {
                if (Time.time - _nextFireTime > _tank.ReloadTime && canFire)
                {
                    _nextFireTime = Time.time;
                    Shoot();

                    _weapon.transform.localRotation = Quaternion.Euler(0, 0, _weapon.transform.localEulerAngles.z + Random.Range(1, 6) / 10);
                }
            }
            else if (hit.collider.CompareTag("Ground"))
            {
                if (_weapon.transform.localRotation.z * 113 <= 6f)
                {
                    _weapon.transform.localRotation = Quaternion.Euler(0, 0, _weapon.transform.localEulerAngles.z - _tank.AimSpeed);
                }
            }
        }
        else
        {
            if (_weapon.transform.localRotation.z * 113 >= -16)
            {
                _weapon.transform.localRotation = Quaternion.Euler(0, 0, _weapon.transform.localEulerAngles.z + _tank.AimSpeed);
            }
        }

        Debug.DrawRay(_firePoint.position, -_firePoint.right * hit.distance, Color.red);
        if (_weapon.transform.localRotation.z * 113 < -16)
            _weapon.transform.localRotation = Quaternion.Euler(0, 0, -16);
        else if (_weapon.transform.localRotation.z * 113 > 6)
            _weapon.transform.localRotation = Quaternion.Euler(0, 0, 6);
    }

    private void Shoot()
    {
        var bullet = Instantiate(_bulletPrefabs[_bulletCount], _firePoint.position, _firePoint.rotation);
        bullet.GetComponent<ArmorPiercingAmmo>().StartMovement(_firePoint);
    }
}
