using UnityEngine.UI;
using UnityEngine;
using UnityEngine.EventSystems;

public class TankSpawner : MonoBehaviour
{
    [SerializeField] private GameObject[] _tanks;

    [SerializeField] private MechanismOfDecklination _mech;
    [SerializeField] private Button _fireButton;
    [SerializeField] private EventTrigger _chainGunTr;

    private GameObject _tank;

    private void OnEnable()
    {
        TankManager.changeWasCompleted += ChangeTanks;
    }

    private void OnDisable()
    {
        TankManager.changeWasCompleted -= ChangeTanks;
    }

    private void Start()
    {
        _tank = _tanks[PlayerPrefs.GetInt("CurTank")];

        _tank.SetActive(true);

        _mech.weapon = _tank.transform.GetChild(1).GetChild(0).GetChild(0).GetChild(0);
        _mech.chainGun = _tank.transform.GetChild(2);
        _mech.tankPos = _tank.transform;
        _mech.tank = _tank.transform.GetChild(1).GetChild(1).GetChild(0).GetComponent<Tank>();

        _fireButton.onClick.AddListener(Add);

        EventTrigger.Entry entry = new EventTrigger.Entry();

        entry.eventID = EventTriggerType.PointerUp;
        entry.callback.AddListener((data) => { AddChUp((PointerEventData)data); });
        _chainGunTr.triggers.Add(entry);

        entry.eventID = EventTriggerType.PointerDown;
        entry.callback.AddListener((data) => { AddChDown((PointerEventData)data); });
        _chainGunTr.triggers.Add(entry);
    }

    private void ChangeTanks()
    {
        GameObject _lastTank = _tank;

        _tank = _tanks[PlayerPrefs.GetInt("CurTank")];

        _mech.weapon = _tank.transform.GetChild(1).GetChild(0).GetChild(0).GetChild(0);
        _mech.chainGun = _tank.transform.GetChild(2);
        _mech.tankPos = _tank.transform;
        _mech.tank = _tank.transform.GetChild(1).GetChild(1).GetChild(0).GetComponent<Tank>();

        _fireButton.onClick.AddListener(Add);

        EventTrigger.Entry entry = new EventTrigger.Entry();

        entry.eventID = EventTriggerType.PointerUp;
        entry.callback.AddListener((data) => { AddChUp((PointerEventData)data); });
        _chainGunTr.triggers.Add(entry);

        entry.eventID = EventTriggerType.PointerDown;
        entry.callback.AddListener((data) => { AddChDown((PointerEventData)data); });
        _chainGunTr.triggers.Add(entry);

        _lastTank.SetActive(false);
        _tank.SetActive(true);
    }

    private void Add()
    {
        _tank.GetComponent<Fire>().FireOnButton();
    }

    private void AddChUp(PointerEventData data)
    {
        _tank.transform.GetChild(3).GetComponent<ChainGun>().OnButtonUp();
    }

    private void AddChDown(PointerEventData data)
    {
        _tank.transform.GetChild(3).GetComponent<ChainGun>().OnButtonDown();
    }
}
