using UnityEngine;
using UnityEngine.UI;

public class Settings : MonoBehaviour
{
    public static Settings instance;

    [SerializeField] private GameObject _settingsPanel;

    [SerializeField] private Slider _musicVolumeSlider;
    [SerializeField] private Slider _soundSlider;

    [SerializeField] private GameObject _musicWasMutedIcon;
    [SerializeField] private GameObject _soundWasMutedIcon;

    private float _lastMusicSet;
    private float _lastSoundSet;

    public float musicVolume;
    public float soundsVolume;
    public bool musicIsMuted;
    public bool soundsIsMuted;

    private void OnDisable()
    {
        PlayerPrefs.SetFloat("MusicVolume", _musicVolumeSlider.value);
        PlayerPrefs.SetFloat("SoundsVolume", _soundSlider.value);
    }

    private void Awake()
    {
        instance = this;
    }

    private void Start()
    {
        _musicVolumeSlider.value = PlayerPrefs.GetFloat("MusicVolume");
        _soundSlider.value = PlayerPrefs.GetFloat("SoundsVolume");

        _lastMusicSet = _musicVolumeSlider.value;
        _lastSoundSet = _soundSlider.value;
    }

    private void Update()
    {
        musicVolume = _musicVolumeSlider.value;
        soundsVolume = _soundSlider.value;

        if (musicVolume == 0) musicIsMuted = true;
        else musicIsMuted = false;

        if (soundsVolume == 0) soundsIsMuted = true;
        else soundsIsMuted = false;

        _musicWasMutedIcon.SetActive(musicIsMuted);
        _soundWasMutedIcon.SetActive(soundsIsMuted);
    }

    public void OpenSettings()
    {
        _settingsPanel.SetActive(true);
    }

    public void CloseSettings()
    {
        _settingsPanel.SetActive(false);
    }

    public void OnMusicButtonPressed()
    {
        if (musicVolume != 0)
        {
            _lastMusicSet = musicVolume;
            _musicVolumeSlider.value = 0;
        }
        else
        {
            if (_lastMusicSet == 0) _lastMusicSet = 100;

            _musicVolumeSlider.value = _lastMusicSet;
        }

    }

    public void OnVolumeButtonPressed()
    {
        if (soundsVolume != 0)
        {
            _lastSoundSet = soundsVolume;
            _soundSlider.value = 0;
        }
        else
        {
            if (_lastSoundSet == 0) _lastSoundSet = 100;

            _soundSlider.value = _lastSoundSet;
        }
    }
}
