using UnityEngine;

public class TankDestroyer : MonoBehaviour
{
    [SerializeField] private Rigidbody2D _tankRB;
    [SerializeField] private Collider2D _armorCol;
    [SerializeField] private GameObject _wheels;
    [SerializeField] private GameObject _caterpillar;

    [SerializeField] private bool _isPlayer;
    [SerializeField] private DamageSystem _sys;
    [SerializeField] private ModulesBar _bar;

    [SerializeField] private GameObject _explosionEffect;
    [SerializeField] private GameObject _ammunitionEffect;

    private void OnEnable()
    {
        if (!_isPlayer)
        {
            _sys.ammunitionWasExploded += Destroy;
            _sys.ammunitionWasExploded += AmmunitionExplosing;
            _sys.tankWasDestroyed += Destroy;
        }
        else
        {
            _bar.ammunitionWasExploded += Destroy;
            _bar.ammunitionWasExploded += AmmunitionExplosing;
            _bar.tankWasDestroyed += Destroy;
        }
    }

    private void OnDisable()
    {
        if (!_isPlayer)
        {
            _sys.ammunitionWasExploded -= Destroy;
            _sys.ammunitionWasExploded -= AmmunitionExplosing;
            _sys.tankWasDestroyed -= Destroy;
        }
        else
        {
            _bar.ammunitionWasExploded -= Destroy;
            _bar.ammunitionWasExploded -= AmmunitionExplosing;
            _bar.tankWasDestroyed -= Destroy;
        }
    }

    public void Destroy()
    {
        _tankRB.bodyType = RigidbodyType2D.Static;
        _armorCol.isTrigger = true;

        foreach (Transform ch in _wheels.transform)
        {
            ch.GetComponent<Collider2D>().enabled = false;
        }

        foreach (Transform ch in _caterpillar.transform)
        {
            ch.GetComponent<Rigidbody2D>().bodyType = RigidbodyType2D.Static;
            ch.GetComponent<Collider2D>().enabled = false;
        }

        if (_isPlayer)
        {
            GetComponent<MovementController>().enabled = false;
            GetComponent<Fire>().enabled = false;
        }
        else
        {
            GetComponent<EnemyMovement>().enabled = false;
            GetComponent<EnemyShootingSystem>().enabled = false;
        }

        _explosionEffect.SetActive(true);
    }
    
    private void AmmunitionExplosing()
    {
        _ammunitionEffect.SetActive(true);
    }
}
