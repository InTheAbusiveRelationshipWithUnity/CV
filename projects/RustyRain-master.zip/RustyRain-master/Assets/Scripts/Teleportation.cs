using System;
using System.Collections;
using UnityEngine;
using UnityEngine.EventSystems;

public class Teleportation : MonoBehaviour, IPointerClickHandler
{
    [SerializeField] private GameObject player;

    [SerializeField] private Transform startPosition;
    [SerializeField] private Transform finalPosition;

    [SerializeField] private GameObject[] objectsOn;
    [SerializeField] private Animator screenAnimator;
    [SerializeField] private CameraFollow cameraFollow;

    [SerializeField] private GameObject _onClickImage;

    public static Action _onTeleported;

    private void Start()
    {
        _onClickImage.SetActive(false);
    }

    public void OnPointerClick(PointerEventData eventData)
    {
        StartCoroutine(SkipScreen());
        StartCoroutine(ActivateAndDisactivateImage());
    }

    IEnumerator SkipScreen()
    {
        screenAnimator.Play("ScreenSkipAnimation");
        yield return new WaitForSeconds(0.45f);


        Teleport();
        ResizeCamera();
        ShowPanels();
        cameraFollow.isActive  = true;
    }

    private void Teleport()
    {
        Camera.main.transform.position = new Vector3(finalPosition.position.x, finalPosition.position.y, Camera.main.transform.position.z);
        player.transform.position = finalPosition.position;
        this.gameObject.SetActive(false);

        _onTeleported?.Invoke();
    }

    private void ResizeCamera()
    {
        Camera.main.orthographicSize = 8f;
    }

    private void ShowPanels()
    {
        for (int i = 0; i < objectsOn.Length; i++)
        {
            objectsOn[i].SetActive(true);
        }
    }

    private IEnumerator ActivateAndDisactivateImage()
    {
        _onClickImage.SetActive(true);
        yield return new WaitForSeconds(1f);
        _onClickImage.SetActive(false);
    }
}
