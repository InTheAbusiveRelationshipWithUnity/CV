using System.Collections;
using UnityEngine;

public class RepairKit : MonoBehaviour
{
    [SerializeField] private Modules _playerModules;

    private bool _canWriteAboutEngine = false;
    private bool _canWriteAboutAmmunition = false;
    private bool _canWriteAboutCrew = false;

    private void OnEnable()
    {
        Modules.engineWasBroken += WriteAboutEngine;
        Modules.ammunitionWasBroken += WriteAboutAmmunition;
        Modules.crewGottenHit += WriteAboutCrew;
    }

    private void OnDisable()
    {
        Modules.engineWasBroken -= WriteAboutEngine;
        Modules.ammunitionWasBroken -= WriteAboutAmmunition;
        Modules.crewGottenHit -= WriteAboutCrew;
    }

    private void WriteAboutEngine()
    {
        _canWriteAboutEngine = true;
        StartCoroutine(ExitOfGUI(0));
    }

    private void WriteAboutAmmunition()
    {
        _canWriteAboutAmmunition = true;
        StartCoroutine(ExitOfGUI(1));
    }

    private void WriteAboutCrew()
    {
        _canWriteAboutCrew = true;
        StartCoroutine(ExitOfGUI(2));
    }

    private void OnGUI()
    {
        GUIStyle style = new(GUI.skin.box)
        {
            fontSize = 24,
            alignment = TextAnchor.MiddleCenter
        };

        if (_canWriteAboutEngine)
        {
            GUI.Box(new Rect(Screen.width / 2 - 125, Screen.height / 4 + 100, 600, 80), "��������� ���������! ��������� ������", style);
        }
        else if (_canWriteAboutAmmunition)
        {
            GUI.Box(new Rect(Screen.width / 2 - 125, Screen.height / 4 + 100, 600, 80), "���������� ����������! ��������� ������", style);
        }
        else if (_canWriteAboutCrew)
        {
            GUI.Box(new Rect(Screen.width / 2 - 125, Screen.height / 4 + 100, 650, 80), "������� ������ ������! ��������� �������� ������", style);
        }
    }

    private IEnumerator ExitOfGUI(int numberOfMessage)
    {
        yield return new WaitForSeconds(3f);

        if (numberOfMessage == 0)
            _canWriteAboutEngine = false;
        else if (numberOfMessage == 1)
            _canWriteAboutAmmunition = false;
        else
            _canWriteAboutCrew = false;
    }

    public void UseRepairKit()
    {
        _playerModules.FixAllModules();
    }

    public void UseKit()
    {
        _playerModules.HealAllCrews();
    }
}