using System;
using UnityEngine;

public class TankManager : MonoBehaviour
{
    private int _numberOfTank = 0;

    public static Action changeWasCompleted;

    public void ChangeTank()
    {
        _numberOfTank = 1;
        PlayerPrefs.SetInt("CurTank", _numberOfTank);

        changeWasCompleted?.Invoke();
    }
}
