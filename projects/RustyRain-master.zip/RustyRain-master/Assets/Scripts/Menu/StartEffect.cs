using UnityEngine;

public class StartEffect : MonoBehaviour
{
    [SerializeField] private Animator _startAnimation;

    private void Start()
    {
        _startAnimation.Play("StartScreenAnimation");
    }
}
