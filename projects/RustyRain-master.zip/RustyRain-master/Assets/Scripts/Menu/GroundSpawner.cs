using System.Collections;
using UnityEngine;

public class GroundSpawner : MonoBehaviour
{
    [SerializeField] private GameObject _otherGround;
    [SerializeField] private Transform _spawnPoint;

    public Collider2D _collider;

    public void TriggerTouch()
    {
        _otherGround.transform.position = new Vector2(_spawnPoint.position.x, _spawnPoint.position.y);
    }
}