using UnityEngine;

public class DrawDashboard : MonoBehaviour
{
    [SerializeField] private Dashboard dashboard;

    private float currentAngle;
    private float targetAngle;
    [SerializeField] private float targetSpeed;

    private float _currentAngleOfFuelArrow;
    private float _targetAngleOfFuel;

    private float _currentAngleOfTachometrArrow;
    private float _targetAngleOfTachometr;

    private float _currentAngleOfTempArrow;
    private float _targetAngleOfTemp;

    private float _currentAngleOfVoltmet�rArrow;
    private float _targetAngleOfVoltmet�r;

    private float _currentAngleOfFuelSwapArrow;
    private float _targetAngleOfFuelSwap;

    private float _currentAngleOfOilArrow;
    private float _targetAngleOfOil;

    private void FixedUpdate()
    {
        targetAngle = ConvertToAngle(dashboard.speedometer.CurrentSpeed, "Speedometr");
        _targetAngleOfFuel = ConvertToAngle(dashboard.fuel.CurrentFuel, "Fuel");
        _targetAngleOfTachometr = ConvertToAngle(dashboard.tachometer.CurrentRPM, "Tachometr");
        _targetAngleOfTemp = ConvertToAngle(dashboard.temp.CurrentTemp, "Temperature");
        _targetAngleOfVoltmet�r = ConvertToAngle(dashboard.voltmeter.CurrentValue, "Voltmeter");
        _targetAngleOfFuelSwap = ConvertToAngle(dashboard.fuelSwap.CurrentValue, "FuelSwap");
        _targetAngleOfOil = ConvertToAngle(dashboard.oil.CurrentValue, "Oil");

        ChangeTheDegree();
    }

    private void Start()
    {
        currentAngle = dashboard.speedometer.CurrentSpeed;
        _currentAngleOfFuelArrow = 0;
        _currentAngleOfTachometrArrow = dashboard.tachometer.CurrentRPM;
        _currentAngleOfTempArrow = dashboard.temp.CurrentTemp;
        _currentAngleOfVoltmet�rArrow = dashboard.voltmeter.CurrentValue;
        _currentAngleOfFuelSwapArrow = dashboard.fuelSwap.CurrentValue;
        _currentAngleOfOilArrow = dashboard.oil.CurrentValue;
    }

    private void ChangeTheDegree()
    {
        currentAngle = Mathf.MoveTowards(currentAngle, targetAngle, targetSpeed);

        dashboard.speedometer.axisOfArrayRotation.eulerAngles = new Vector3(
            dashboard.speedometer.axisOfArrayRotation.eulerAngles.x,
            dashboard.speedometer.axisOfArrayRotation.eulerAngles.y,
            -currentAngle);

        _currentAngleOfFuelArrow = Mathf.MoveTowards(_currentAngleOfFuelArrow, _targetAngleOfFuel, targetSpeed);
        dashboard.fuel.axisOfArrayRotation.eulerAngles = new Vector3(
            dashboard.fuel.axisOfArrayRotation.eulerAngles.x,
            dashboard.fuel.axisOfArrayRotation.eulerAngles.y,
            _currentAngleOfFuelArrow);

        _currentAngleOfTachometrArrow = Mathf.MoveTowards(_currentAngleOfTachometrArrow, _targetAngleOfTachometr, targetSpeed);

        dashboard.tachometer.axisOfArrayRotation.eulerAngles = new Vector3(
            dashboard.tachometer.axisOfArrayRotation.eulerAngles.x,
            dashboard.tachometer.axisOfArrayRotation.eulerAngles.y,
            -_currentAngleOfTachometrArrow);

        _currentAngleOfTempArrow = Mathf.MoveTowards(_currentAngleOfTempArrow, _targetAngleOfTemp, targetSpeed);

        dashboard.temp.axisOfArrayRotation.eulerAngles = new Vector3(
            dashboard.temp.axisOfArrayRotation.eulerAngles.x,
            dashboard.temp.axisOfArrayRotation.eulerAngles.y,
            -_currentAngleOfTempArrow);

        _currentAngleOfVoltmet�rArrow = Mathf.MoveTowards(_currentAngleOfVoltmet�rArrow, _targetAngleOfVoltmet�r, targetSpeed);

        dashboard.voltmeter.axisOfArrayRotation.eulerAngles = new Vector3(
            dashboard.voltmeter.axisOfArrayRotation.eulerAngles.x,
            dashboard.voltmeter.axisOfArrayRotation.eulerAngles.y,
            _currentAngleOfVoltmet�rArrow);

        _currentAngleOfFuelSwapArrow = Mathf.MoveTowards(_currentAngleOfFuelSwapArrow, _targetAngleOfFuelSwap, targetSpeed);

        dashboard.fuelSwap.axisOfArrayRotation.eulerAngles = new Vector3(
            dashboard.fuelSwap.axisOfArrayRotation.eulerAngles.x,
            dashboard.fuelSwap.axisOfArrayRotation.eulerAngles.y,
            _currentAngleOfFuelSwapArrow);

        _currentAngleOfOilArrow = Mathf.MoveTowards(_currentAngleOfOilArrow, _targetAngleOfOil, targetSpeed);

        dashboard.oil.axisOfArrayRotation.eulerAngles = new Vector3(
            dashboard.oil.axisOfArrayRotation.eulerAngles.x,
            dashboard.oil.axisOfArrayRotation.eulerAngles.y,
            _currentAngleOfOilArrow);
    }

    private float ConvertToAngle(float speed, string whatIsThisDevice)
    {
        if (whatIsThisDevice == "Speedometr")
        {
            float anglesPoints = -dashboard.speedometer.MinumumAngle + dashboard.speedometer.MaximumAngle;
            float speedPoints = dashboard.speedometer.MaximumSpeed;

            float convertedAnglePoints = speed * (anglesPoints / speedPoints);

            return convertedAnglePoints - dashboard.speedometer.MaximumAngle;
        }
        else if (whatIsThisDevice == "Fuel")
        {
            float anglesPoints = -dashboard.fuel.MinumumAngle + dashboard.fuel.MaximumAngle;
            float speedPoints = dashboard.fuel.MaximumFuel;

            float convertedAnglePoints = speed * (anglesPoints / speedPoints);

            return convertedAnglePoints - dashboard.fuel.MaximumAngle;
        }
        else if (whatIsThisDevice == "Tachometr")
        {
            float anglesPoints = -dashboard.tachometer.MinumumAngle + dashboard.tachometer.MaximumAngle;
            float speedPoints = dashboard.tachometer.MaximumRPM;

            float convertedAnglePoints = speed * (anglesPoints / speedPoints);

            return convertedAnglePoints - dashboard.tachometer.MaximumAngle;
        }
        else if (whatIsThisDevice == "Temperature")
        {
            float anglesPoints = -dashboard.temp.MinumumAngle + dashboard.temp.MaximumAngle;
            float speedPoints = dashboard.temp.MaximumTemp;

            float convertedAnglePoints = speed * (anglesPoints / speedPoints);

            return convertedAnglePoints - dashboard.temp.MaximumAngle;
        }
        else if (whatIsThisDevice == "Voltmeter")
        {
            float anglesPoints = -dashboard.voltmeter.MinumumAngle + dashboard.voltmeter.MaximumAngle;
            float speedPoints = dashboard.voltmeter.MaximumValue;

            float convertedAnglePoints = speed * (anglesPoints / speedPoints);

            return convertedAnglePoints - dashboard.voltmeter.MaximumAngle;
        }
        else if (whatIsThisDevice == "FuelSwap")
        {
            float anglesPoints = -dashboard.fuelSwap.MinumumAngle + dashboard.fuelSwap.MaximumAngle;
            float speedPoints = dashboard.fuelSwap.MaximumValue;

            float convertedAnglePoints = speed * (anglesPoints / speedPoints);

            return convertedAnglePoints - dashboard.fuelSwap.MaximumAngle;
        }
        else if (whatIsThisDevice == "Oil")
        {
            float anglesPoints = -dashboard.oil.MinumumAngle + dashboard.oil.MaximumAngle;
            float speedPoints = dashboard.oil.MaximumValue;

            float convertedAnglePoints = speed * (anglesPoints / speedPoints);

            return convertedAnglePoints - dashboard.oil.MaximumAngle;
        }
        else { return 0f; }
    }
}