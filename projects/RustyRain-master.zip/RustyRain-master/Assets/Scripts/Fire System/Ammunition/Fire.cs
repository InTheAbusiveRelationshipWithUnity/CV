using System.Collections;
using UnityEngine;

public class Fire : MonoBehaviour
{
    public static Fire instance;

    private float _nextFireTime = 0;

    [SerializeField] private Tank _tank;

    [SerializeField] private GameObject[] _bulletPrefabs;
    private int _currentChangedAmmo = 0;

    [Header("Animation")]
    [SerializeField] private Animation _fireAnim;

    [Header("ParticleSystem")]
    [SerializeField] private ParticleSystem _firePart;
    public Transform _firePoint;

    [SerializeField] private Transform _weapon;

    private bool _isMobilePlatform = false;

    public bool canFire = true;

    private void Awake()
    {
        instance = this;

        if (Application.isMobilePlatform)
            _isMobilePlatform = true;
    }

    private void Update()
    {
        if (Input.GetMouseButtonDown(0) && !_isMobilePlatform)
        {
            Shoot();
        }
        RaycastHit2D hit = Physics2D.Raycast(_firePoint.position, -_firePoint.forward, 10000);
        Debug.DrawRay(_firePoint.position, hit.point);
    }

    public void Shoot()
    {
        if (Time.time - _nextFireTime >= _tank.ReloadTime && canFire)
        {
            _nextFireTime = Time.time;

            WeaponAnim();

            if (_currentChangedAmmo == 0)
            {
                var bullet = Instantiate(_bulletPrefabs[_currentChangedAmmo], _firePoint.position, Quaternion.Euler(_firePoint.rotation.x, _firePoint.rotation.y, _firePoint.rotation.z)).GetComponent<ArmorPiercingAmmo>();
                bullet.StartMovement(_firePoint);
            }
            else if (_currentChangedAmmo == 1)
            {
                var bullet = Instantiate(_bulletPrefabs[_currentChangedAmmo], _firePoint.position, Quaternion.Euler(_firePoint.rotation.x, _firePoint.rotation.y, _firePoint.rotation.z));
            }

            Instantiate(_firePart, _firePoint.position, _firePoint.rotation);
        }
    }

    public void ChangeAPAmmo()
    {
        _currentChangedAmmo = 0;
    }

    public void ChangeHEAmmo()
    {
        _currentChangedAmmo = 1;
    }

    public void ChangeCumulAmmo()
    {
        _currentChangedAmmo = 2;
    }

    private void WeaponAnim()
    {
        _fireAnim.Play(_fireAnim.clip.name);
    }

    public void FireOnButton()
    {
        Shoot();
    }
}
