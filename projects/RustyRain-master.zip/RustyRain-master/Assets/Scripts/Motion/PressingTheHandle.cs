using UnityEngine;
using UnityEngine.EventSystems;

public class PressingTheHandle : MonoBehaviour, IBeginDragHandler, IEndDragHandler, IPointerDownHandler, IPointerUpHandler
{
    [SerializeField] private Animator animator;

    public void OnEndDrag(PointerEventData eventData)
    {
        animator.Play("WringOut");
    }
    public void OnPointerUp(PointerEventData eventData)
    {
        animator.Play("WringOut");
    }

    public void OnPointerDown(PointerEventData eventData)
    {
        animator.Play("Press");
    }

    public void OnBeginDrag(PointerEventData eventData)
    {
        animator.Play("Press");
    }

}
