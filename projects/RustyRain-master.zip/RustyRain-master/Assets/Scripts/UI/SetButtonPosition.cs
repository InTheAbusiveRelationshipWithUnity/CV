using UnityEngine.UI;
using UnityEngine;

public class SetButtonPosition : MonoBehaviour
{
    [SerializeField] private Image _panel;

    [SerializeField] private Button[] _buttons;
    [SerializeField] private MechanismOfDecklination _mechanismOfDecklination;
    [SerializeField] private ChainGun _chainGun;
    [SerializeField] private CameraZoom _zoom;
    [SerializeField] private TurningTheHandle _turningTheHandle;
    [SerializeField] private Slider _slider;

    [SerializeField] private RectTransform[] _pos;

    private void Start()
    {
        Set();
    }

    public void Change()
    {
        _panel.gameObject.SetActive(true);

        _pos[2].gameObject.SetActive(true);
        _pos[9].gameObject.SetActive(true);
        _pos[4].gameObject.SetActive(true);
        _pos[5].gameObject.SetActive(true);

        foreach (var button in _buttons)
            button.enabled = false;
        _mechanismOfDecklination.enabled = false;
        _chainGun.enabled = false;
        _zoom.enabled = false;
        _turningTheHandle.enabled = false;
        _slider.enabled = false;

        foreach (var b in _pos)
        {
            b.GetComponent<ButtonTransitor>().enabled = true;
        }
    }

    public void Set()
    {
        _panel.gameObject.SetActive(false);

        foreach (var button in _buttons)
            button.enabled = true;
        _mechanismOfDecklination.enabled = true;
        _chainGun.enabled = true;
        _zoom.enabled = true;
        _turningTheHandle.enabled = true;
        _slider.enabled = true;

        PlayerPrefs.SetFloat("DashboardX", _pos[0].anchoredPosition.x);
        PlayerPrefs.SetFloat("DashboardY", _pos[0].anchoredPosition.y);
        PlayerPrefs.SetFloat("LeverX", _pos[1].anchoredPosition.x);
        PlayerPrefs.SetFloat("LeverY", _pos[1].anchoredPosition.y);
        PlayerPrefs.SetFloat("MapLineX", _pos[2].anchoredPosition.x);
        PlayerPrefs.SetFloat("MapLineY", _pos[2].anchoredPosition.y);
        PlayerPrefs.SetFloat("ZoomButtonX", _pos[3].anchoredPosition.x);
        PlayerPrefs.SetFloat("ZoomButtonY", _pos[3].anchoredPosition.y);
        PlayerPrefs.SetFloat("FireButtonX", _pos[4].anchoredPosition.x);
        PlayerPrefs.SetFloat("FireButtonY", _pos[4].anchoredPosition.y);
        PlayerPrefs.SetFloat("ChaingunButtonX", _pos[5].anchoredPosition.x);
        PlayerPrefs.SetFloat("ChaingunButtonY", _pos[5].anchoredPosition.y);
        PlayerPrefs.SetFloat("ModulesBarX", _pos[6].anchoredPosition.x);
        PlayerPrefs.SetFloat("ModulesBarY", _pos[6].anchoredPosition.y);
        PlayerPrefs.SetFloat("AmmunitionPanelX", _pos[7].anchoredPosition.x);
        PlayerPrefs.SetFloat("AmmunitionPanelY", _pos[7].anchoredPosition.y);
        PlayerPrefs.SetFloat("SettingsButtonX", _pos[8].anchoredPosition.x);
        PlayerPrefs.SetFloat("SettingsButtonY", _pos[8].anchoredPosition.y);
        PlayerPrefs.SetFloat("MechX", _pos[9].anchoredPosition.x);
        PlayerPrefs.SetFloat("MechY", _pos[9].anchoredPosition.y);

        foreach (var b in _pos)
        {
            b.GetComponent<ButtonTransitor>().enabled = false;
        }

        _pos[2].gameObject.SetActive(false);
        _pos[9].gameObject.SetActive(false);
        _pos[4].gameObject.SetActive(false);
        _pos[5].gameObject.SetActive(false);
    }
}
