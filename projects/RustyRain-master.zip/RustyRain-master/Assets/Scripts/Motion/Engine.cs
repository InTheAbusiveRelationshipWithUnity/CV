﻿using UnityEngine;

public class Engine : MonoBehaviour
{
    [SerializeField] private float[] _gearRatios;
    [SerializeField] private float _differntialRatio;
    [SerializeField] private float _cluth;
    public float Cluth
    {
        set { _cluth = value; }
        get { return _cluth; }
    }

    private float _maximumTorque;
    private float _currentTorque;
    private float _currentGear;
    public float CurrentTorque
    {
        get { return _currentTorque; }
    }
    private static float _minimumTorque = 0f;

    private float _motorSpeed;

    private float _power;

    private float _RPM;
    private float _wheelRPM;
    private float _idleRPM;
    private float _maximumRPM;

    private float _maximumTurnovers;
    private float _currentTurnovers;
    private static float _minimumTurnovers = 0f;

    private float _fuelConsumptionPerSecond;
    private float _oilConsumptionPercentageOfFuelConsumption;

    public void CalculateTorque()
    {
        float torque = 0;

        //if (isEngineRunning > 0)
        //{
        //    if (_cluth<=0.1f)
        //    {
        //        _RPM = Mathf.Lerp(_RPM, Mathf.Max(_idleRPM, _maximumRPM * gasInput) + Random.Range(-50, 50), Time.deltaTime);
        //    }
        //    else
        //    {
        //        _wheelRPM = (360f / _motorSpeed) / 60f * _gearRatios[_currentGear] * _differntialRatio;
        //    }
        //}
    }
}
